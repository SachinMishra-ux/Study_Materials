from langchain_core.prompts import PromptTemplate
from langchain_core.documents import Document
from Scripts.inference.llm_setup import initialize_llm
import os

def generate_comprehensive_syllabus(txt_file_path: str, azure_deployment: str, api_version: str,
                                     azure_endpoint: str, api_key: str, output_path: str = None):
    # Step 1: Load content from .txt
    with open(txt_file_path, 'r', encoding='utf-8') as f:
        raw_content = f.read().strip()

    # Step 2: Create a LangChain Document object
    document = Document(page_content=raw_content, metadata={"source": "NX curriculum"})

    # Step 3: Prompt template
    prompt = PromptTemplate.from_template(
        """You are an expert mechanical design trainer. Given the following NX course outline, write a detailed and comprehensive syllabus.
        Structure it by modules/units and include a 1-2 line explanation per module. It should not exceed the word count of 3000.

Course Outline:
{content}
"""
    )

    # Step 4: Initialize Azure OpenAI LLM
    llm = initialize_llm(azure_deployment, api_version, azure_endpoint, api_key)

    # Step 5: Chain the input through the prompt and LLM
    chain = prompt | llm

        # Step 6: Run it
    print("🧠 Generating comprehensive syllabus from NX course outline...")
    response = chain.invoke({"content": document.page_content})

    # Step 7: Save or print output
    if output_path:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(response.content)
        print(f"✅ Syllabus saved at {output_path}")
    else:
        print("\n🎓 Syllabus:\n", response.content)

    return response.content


if __name__=="__main__":
    from dotenv import load_dotenv
    load_dotenv(override=True)
    generate_comprehensive_syllabus(
        txt_file_path=r"C:\Users\smm931389\Desktop\IGETITV2-Learner-ChatBot-API\course_unit_mapping.txt",
        azure_deployment=os.getenv("AZURE_LLM_DEPLOYMENT"),
        api_version=os.getenv("AZURE_LLM_API_VERSION"),
        azure_endpoint=os.getenv("AZURE_LLM_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_LLM_OPENAI_API_KEY"),
        output_path="nx_comprehensive_syllabus.txt"
    )
