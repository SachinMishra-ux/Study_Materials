from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SearchField,
    SearchFieldDataType,
    SimpleField,
    SearchableField,
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchAlgorithmKind,
    VectorSearchProfile,
)
import os
from langchain_openai import AzureOpenAIEmbeddings
from src.constants import INDEX_NAME

from azure.core.pipeline.transport import RequestsTransport

os.environ["TIKTOKEN_CACHE_DIR"] = (
    r"C:\Users\smm931389\Desktop\IGETITV2-Learner-ChatBot-API\cl100k_base.tiktoken"
)

transport = RequestsTransport(connection_verify=False)

from dotenv import load_dotenv


def create_vector_search_index(index_name: str, endpoint: str, api_key: str) -> None:
    """
    Creates a vector search index in Azure Search.

    This function creates an index with fields suitable for storing both textual content
    and vector embeddings.  It uses the HNSW algorithm for efficient vector search.
    If an index with the given name already exists, it is deleted and recreated.

    Args:
        index_name: The name of the index to create.
    """

    credential = AzureKeyCredential(api_key)
    index_client = SearchIndexClient(
        endpoint=endpoint, credential=credential, transport=transport
    )

    # Define the fields for the index.
    fields = [
        SimpleField(name="id", type=SearchFieldDataType.String, key=True),
        SearchableField(
            name="content", type=SearchFieldDataType.String, analyzer_name="en.lucene"
        ),
        SimpleField(
            name="source",
            type=SearchFieldDataType.String,
            filterable=True,
            sortable=True,
        ),
        SearchField(
            name="content_vector",
            type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
            searchable=True,
            vector_search_dimensions=1536,
            vector_search_profile_name="default-vector-profile",
        ),
    ]
    # Define the vector search configuration
    vector_search_config = VectorSearch(
        algorithms=[
            HnswAlgorithmConfiguration(
                name="default-hnsw",
                kind=VectorSearchAlgorithmKind.HNSW,
                parameters={"m": 4, "efConstruction": 400, "metric": "cosine"},
            )
        ],
        profiles=[
            VectorSearchProfile(
                name="default-vector-profile",
                algorithm_configuration_name="default-hnsw",
            )
        ],
    )
    # Create the index.
    index = SearchIndex(
        name=index_name, fields=fields, vector_search=vector_search_config
    )

    # Check if the index exists and delete it if it does.
    if index_name in [idx.name for idx in index_client.list_indexes()]:
        print(f"ℹ️ Index '{index_name}' already exists. Deleting and recreating...")
        index_client.delete_index(index_name)

    # Create the new index.
    index_client.create_index(index)
    print(f"✅ Created Azure Search index '{index_name}' with expected fields.")


# Function to validate document structure


def validate_documents(documents: list) -> None:
    """
    Validates the structure of a list of documents before uploading to Azure Search.

    This function checks that each document in the list has the required fields
    ('id', 'content', 'source', 'content_vector') with the correct data types.
    It also checks the dimensions of the content vector.

    Args:
        documents: A list of dictionaries, where each dictionary represents a document.

    Raises:
        AssertionError: If any document in the list does not conform to the expected structure.
    """
    for i, d in enumerate(documents):
        assert isinstance(d.get("id"), str), f"Doc {i} missing 'id' or not a string"
        assert isinstance(
            d.get("content"), str
        ), f"Doc {i} missing 'content' or not a string"
        assert isinstance(
            d.get("source"), str
        ), f"Doc {i} missing 'source' or not a string"
        vec = d.get("content_vector")
        assert isinstance(vec, list), f"Doc {i} 'content_vector' is not a list"
        assert all(
            isinstance(x, float) for x in vec
        ), f"Doc {i} vector must contain only floats"
        assert len(vec) == 1536, f"Doc {i} vector must be length 1536"


def get_azure_openai_embeddings() -> AzureOpenAIEmbeddings:
    """
    Retrieves an AzureOpenAIEmbeddings object configured to use your Azure OpenAI deployment.

    This function reads the necessary configuration from environment variables
    (AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_OPENAI_DEPLOYMENT, AZURE_OPENAI_API_VERSION)
    and returns an instance of AzureOpenAIEmbeddings.

    Returns:
        An AzureOpenAIEmbeddings object, or None if an error occurs.
    """
    try:
        return AzureOpenAIEmbeddings(
            deployment=os.getenv(
                "AZURE_OPENAI_EMBEDDING_DEPLOYMENT"
            ),  # e.g., "text-embedding-ada-002-2"
            model="text-embedding-ada-002",
            openai_api_version=os.getenv(
                "AZURE_OPENAI_API_VERSION"
            ),  # e.g., "2023-12-01-preview"
            openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            azure_endpoint=os.getenv(
                "AZURE_OPENAI_ENDPOINT"
            ),  # e.g., "https://<your-resource-name>.openai.azure.com/"
        )
    except Exception as e:
        print(f"Error initializing Azure OpenAI embeddings: {e}")
        raise e


# Function to generate embeddings for the query
def generate_query_embedding(query: str) -> list:
    """
    Generates the vector embedding for a given query string using Azure OpenAI.

    This function uses the AzureOpenAIEmbeddings client to convert the query
    into a vector representation.

    Args:
        query: The query string to embed.

    Returns:
        A list of floats representing the query's vector embedding.

    Raises:
        Exception: If the Azure OpenAI embeddings client cannot be initialized.
    """
    embedder = get_azure_openai_embeddings()
    if embedder is None:
        raise Exception("⚠️ Could not initialize Azure OpenAI embeddings.")

    # Convert the query to an embedding.
    query_embedding = embedder.embed_query(query)
    return query_embedding


def is_vector_search_enabled(index_name: str, endpoint: str, api_key: str) -> bool:
    """
    Checks if vector search is enabled for a given Azure Search index.

    This function retrieves the index definition and checks for the presence of a
    vector search configuration.

    Args:
        index_name: The name of the index to check.
        endpoint: The Azure Search endpoint.
        api_key: The Azure Search API key.

    Returns:
        True if vector search is enabled, False otherwise.
    """
    credential = AzureKeyCredential(api_key)
    index_client = SearchIndexClient(
        endpoint=endpoint, credential=credential, transport=transport
    )

    try:
        index = index_client.get_index(index_name)
        return hasattr(index, "vector_search") and index.vector_search is not None
    except Exception as e:
        print(f"Error checking vector search status: {e}")
        return False


if __name__ == "__main__":
    load_dotenv()
    endpoint = os.getenv("AZURE_SEARCH_ENDPOINT")
    api_key = os.getenv("AZURE_SEARCH_KEY")
    create_vector_search_index(INDEX_NAME, endpoint, api_key)
    is_vector_search_enabled(INDEX_NAME, endpoint, api_key)
