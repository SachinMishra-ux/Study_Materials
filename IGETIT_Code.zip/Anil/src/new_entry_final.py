from logger import get_logger
from typing import TypedDict, List, Optional
from langchain.schema import Document
from langgraph.graph import StateGraph, END

from langchain_core.callbacks.streaming_stdout import StreamingStdOutCallbackHandler

from web_utils import fetch_web_documents
from cosmos_helper import (
    get_conversation_history,
    format_chat_history,
    get_semantically_similar_answer,
    generate_query_embedding,
    save_message,
)
from llm_module import build_rag_chain, initialize_llm, get_relevant_documents

logger = get_logger("RAGPipeline")
# Initialize LLM & chain once
_llm = initialize_llm()
_rag_chain = build_rag_chain(_llm)


# === 1. Define the State Schema ===
class RAGState(TypedDict):
    question: str
    session_id: str
    embedding: List[float]
    chat_history: str
    documents: List[Document]
    answer: Optional[str]
    next: Optional[str]
    web_searched: Optional[bool]
    from_cache: Optional[bool]
    steps: List[dict]  # Track agent actions


# === 2. Pre-compute embedding node ===
def compute_embedding_node(state: RAGState):
    """
    Compute the embedding once and stash it in state.
    """
    emb = generate_query_embedding(state["question"])
    state["steps"].append(
        {
            "action": "Compute Embedding",
            "details": "Generated embedding for the question.",
        }
    )
    return {"embedding": emb, "next": "check_cached_answer"}


# === 3. Cache check uses the precomputed embedding ===
def check_cache_node(state: RAGState):
    emb = state["embedding"]
    cached_answer = get_semantically_similar_answer(
        question=state["question"],
        session_id=state["session_id"],
        query_embedding=emb,
        threshold=0.95,
    )
    if cached_answer:
        state["steps"].append(
            {
                "action": "Cache Check",
                "details": "Found cached answer for the question.",
            }
        )
        return {"answer": cached_answer, "next": "END"}
    state["steps"].append(
        {"action": "Cache Check", "details": "No cached answer found."}
    )
    return {"next": "summarize_history"}


# === 4. History summarization & check ===
def summarize_history_node(state: RAGState):
    history = get_conversation_history(state["session_id"])
    state["steps"].append(
        {
            "action": "Summarize History",
            "details": f"Summarized conversation history for session {state['session_id']}.",
        }
    )
    return {
        "chat_history": format_chat_history(history),
        "next": "check_history_answer",
    }


def check_history_answer_node(state: RAGState):
    question = state["question"]
    chat_history = state.get("chat_history", "")
    if not chat_history.strip():
        return {"next": "check_docs"}

    result = _rag_chain.invoke(
        {"question": question, "chat_history": chat_history, "context": []}
    )
    answer_text = getattr(result, "content", str(result)).strip()
    if "internal docs are not sufficient" in answer_text.lower():
        state["steps"].append(
            {
                "action": "History Answer Check",
                "details": "Insufficient history context, moving to document search.",
            }
        )
        return {"next": "check_docs"}

    # buffer save using the same embedding
    save_message(state["session_id"], "user", question, embedding=state["embedding"])
    save_message(state["session_id"], "assistant", answer_text)
    state["steps"].append(
        {
            "action": "History Answer Check",
            "details": "Found sufficient history context, answer generated.",
        }
    )
    return {"answer": answer_text, "from_cache": False, "next": "END"}


# === 5. Document lookup nodes ===
def check_docs_node(state: RAGState):
    if state.get("web_searched"):
        state["steps"].append(
            {
                "action": "Check Documents",
                "details": "Already performed web search, skipping.",
            }
        )
        return {"next": "generate_answer"}

    docs = get_relevant_documents(state["question"])
    if docs:
        state["steps"].append(
            {
                "action": "Check Documents",
                "details": f"Found {len(docs)} relevant internal documents.",
            }
        )
        return {"documents": docs, "next": "generate_answer"}

    state["steps"].append(
        {
            "action": "Check Documents",
            "details": "No relevant documents found, proceeding to web search.",
        }
    )
    return {"next": "web_search"}


def web_search_node(state: RAGState):
    docs = fetch_web_documents(state["question"], _llm)
    if docs:
        state["steps"].append(
            {
                "action": "Web Search",
                "details": "Performed web search and found relevant documents.",
            }
        )
        return {"documents": docs, "web_searched": True, "next": "generate_answer"}
    state["steps"].append(
        {"action": "Web Search", "details": "No relevant information found on the web."}
    )
    return {
        "answer": "❌ I couldn't find anything relevant on the web either.",
        "web_searched": True,
        "next": "END",
    }


# === 6. Answer generation uses the same embedding again ===
def generate_answer_node(state: RAGState):
    docs = state.get("documents", [])

    # save user message once more
    save_message(
        state["session_id"], "user", state["question"], embedding=state["embedding"]
    )

    # if web-sourced docs, short-circuit
    if state.get("web_searched") and docs:
        web_answer = docs[0].page_content.strip()
        save_message(state["session_id"], "assistant", web_answer)
        state["steps"].append(
            {
                "action": "Generate Answer",
                "details": "Generated answer from web-sourced documents.",
            }
        )
        return {**state, "answer": web_answer, "next": "END"}

    result = _rag_chain.invoke(
        {
            "question": state["question"],
            "chat_history": state["chat_history"],
            "context": docs,
        }
    )
    answer_text = getattr(result, "content", str(result)).strip()
    if "internal docs are not sufficient" in answer_text.lower() and not state.get(
        "web_searched"
    ):
        state["steps"].append(
            {
                "action": "Generate Answer",
                "details": "Internal documents insufficient, proceeding to web search.",
            }
        )
        return {**state, "next": "web_search"}

    save_message(state["session_id"], "assistant", answer_text)
    state["steps"].append(
        {
            "action": "Generate Answer",
            "details": "Generated answer from internal documents.",
        }
    )
    return {**state, "answer": answer_text, "next": "END"}


# === 7. Build & compile the graph once ===
def build_agentic_rag_graph():
    wf = StateGraph(state_schema=RAGState)
    wf.add_node("compute_embedding", compute_embedding_node)
    wf.add_node("check_cached_answer", check_cache_node)
    wf.add_node("summarize_history", summarize_history_node)
    wf.add_node("check_history_answer", check_history_answer_node)
    wf.add_node("check_docs", check_docs_node)
    wf.add_node("web_search", web_search_node)
    wf.add_node("generate_answer", generate_answer_node)

    wf.set_entry_point("compute_embedding")

    wf.add_conditional_edges(
        "compute_embedding",
        path=lambda s: s.get("next", "check_cached_answer"),
        path_map={"check_cached_answer": "check_cached_answer"},
    )
    wf.add_conditional_edges(
        "check_cached_answer",
        path=lambda s: s.get(
            "next", "summarize_history" if s.get("next") else "summarize_history"
        ),
        path_map={"summarize_history": "summarize_history", "END": END},
    )
    wf.add_conditional_edges(
        "summarize_history",
        path=lambda s: s.get("next", "check_history_answer"),
        path_map={
            "check_history_answer": "check_history_answer",
            "check_docs": "check_docs",
        },
    )
    wf.add_conditional_edges(
        "check_history_answer",
        path=lambda s: s.get("next", "check_docs"),
        path_map={"check_docs": "check_docs", "END": END},
    )
    wf.add_conditional_edges(
        "check_docs",
        path=lambda s: s.get("next", "generate_answer"),
        path_map={"generate_answer": "generate_answer", "web_search": "web_search"},
    )
    wf.add_edge("web_search", "generate_answer")
    wf.add_conditional_edges(
        "generate_answer",
        path=lambda s: s.get("next", "END"),
        path_map={"web_search": "web_search", "END": END},
    )

    return wf.compile()


# === 8. run_rag_pipeline ===
def run_rag_pipeline(question: str, session_id: str, compiled_graph) -> dict:
    initial_state = {
        "question": question,
        "session_id": session_id,
        # 'embedding' will be filled by the first node
        "embedding": None,
        "chat_history": "",
        "documents": [],
        "answer": None,
        "next": None,
        "web_searched": False,
        "from_cache": False,
        "steps": [],  # Track agent actions
    }
    result = compiled_graph.invoke(initial_state)
    return {
        "response": result.get("answer", "❌ No answer could be generated."),
        "steps": result.get("steps", []),
    }


# Standalone test
if __name__ == "__main__":
    import time

    # 1. Build the graph once
    compiled_graph = build_agentic_rag_graph()

    # 2. Your test question/session
    question = "Where can I find the Command finder button in NX"
    session_id = "tesla_session_1"

    # 3. Measure
    start = time.perf_counter()
    result = run_rag_pipeline(question, session_id, compiled_graph)
    end = time.perf_counter()

    elapsed_seconds = end - start
    print(f"Question: {question!r}")
    print(f"Answer: {result['response']!r}")
    print(f"Elapsed time: {elapsed_seconds*1000:.1f} ms")
    print(f"Steps: {result['steps']}")
