import os
import pandas as pd
from collections import defaultdict

import os
import pandas as pd
from collections import defaultdict

import os
import pandas as pd
from collections import defaultdict

import os
import pandas as pd
from collections import defaultdict

def map_unit_to_docs_and_save(folder_path, output_file):
    """
    Reads all CSV files in a folder, maps UnitTitle to a list of DocTitles,
    logs each file being processed line-by-line, and saves the output to a text file.
    """
    unit_doc_map = defaultdict(list)

    # Sort files naturally (e.g., curriculum (2) before curriculum (10))
    from natsort import natsorted
    files = natsorted([file for file in os.listdir(folder_path) if file.endswith('.csv')])

    with open(output_file, 'w', encoding='utf-8') as f_out:
        for file in files:
            print(f"Processing file: {file}")  # Ensures one file per line on console
            f_out.write(f"--- Mapping from file: {file} ---\n")

            file_path = os.path.join(folder_path, file)
            try:
                df = pd.read_csv(file_path, encoding='utf-8')
            except UnicodeDecodeError:
                df = pd.read_csv(file_path, encoding='latin1')

            if 'UnitTitle' in df.columns and 'DocTitle' in df.columns:
                grouped = df.groupby('UnitTitle')['DocTitle'].apply(list).to_dict()
                for unit_title, doc_titles in grouped.items():
                    f_out.write(f"\n{unit_title}:\n")
                    for doc in doc_titles:
                        f_out.write(f"  - {doc.strip()}\n")
                    f_out.write("\n")

    print(f"\n✅ Mapping saved to: {output_file}")


import json
import uuid

def create_rag_json_from_txt(
    txt_file_path,
    output_json_path,
    course_id="17139",
    category="NX",
    subcategory="NX5",
    course_title="NX Course Syllabus",
    skill_level="Basic",
    doc_id="368265",
    doc_url="https://appv2.myigetit.com/learning?Catalog-1?CategoryID=2"
):
    """
    Converts cleaned syllabus text into a structured JSON record, removing any '.csv' lines
    and flattening the content into a single line.
    """
    with open(txt_file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    # Filter out lines containing '.csv' and flatten
    filtered_lines = []
    for line in lines:
        if '.csv' in line:
            continue
        line = line.strip()
        if line:
            filtered_lines.append(line)

    flat_text = " ".join(filtered_lines)  # All text in one line

    # Create unique blob path
    blob_path = f"course-docs/course-docs/content_{str(uuid.uuid4())}.txt"
    record_id = f"{course_id}_{doc_id}"

    json_data = {
        "id": record_id,
        "BlobPath": blob_path,
        "CategoryName": category,
        "SubCategoryName": subcategory,
        "CourseID": course_id,
        "CourseTitle": course_title,
        "UnitTitle": course_title,
        "DocID": doc_id,
        "DocTitle": course_title,
        "SkillLevel": skill_level,
        "DocURL": doc_url,
        "SubscriptionIDs": [],
        "text_content": flat_text,
        "text_embedding": []
    }

    with open(output_json_path, 'w', encoding='utf-8') as out_f:
        json.dump(json_data, out_f, indent=2, ensure_ascii=False)

    print(f"✅ Final JSON created at: {output_json_path}")




if __name__=="__main__":
    folder_path = r"C:\Users\smm931389\Desktop\IGETITV2-Learner-ChatBot-API\curriculum_NX"
    map_unit_to_docs_and_save(folder_path, "course_unit_mapping.txt")
    create_rag_json_from_txt(
    txt_file_path=r"C:\Users\smm931389\Desktop\IGETITV2-Learner-ChatBot-API\course_unit_mapping.txt",
    output_json_path="NX.json"
    )



