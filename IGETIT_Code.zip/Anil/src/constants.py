#Azure Blob containers to load data from
CONTAINERS = ["course-ppt","course-pdf","course-docs"]
#ACCOUNT = "chatbotnxfiles"
#INDEX_NAME= "course-index"

#CONTAINERS= ["ai-chatbot"]
ACCOUNT="igetit"
INDEX_NAME= "course-index1"
