# Replace 'your_file.txt' with your actual file name
with open(r"C:\Users\smm931389\Desktop\IGETITV2-Learner-ChatBot-API\nx_comprehensive_syllabus.txt", "r", encoding="utf-8") as file:
    single_line_content = file.read().replace("\n", " ")

# Optionally print or save it
print(single_line_content)

# To save the single-line content to a new file (optional)
with open("single_line_output.txt", "w", encoding="utf-8") as outfile:
    outfile.write(single_line_content)
