from azure.cosmos import CosmosClient
from langchain.schema import AIMessage, HumanMessage
import os
import numpy as np
from typing import List
from src.index_helper import generate_query_embedding  # Already imported
from langchain.schema import Document
from dotenv import load_dotenv

load_dotenv()

# Load credentials
COSMOS_ENDPOINT = os.getenv("COSMOS_ENDPOINT")
COSMOS_KEY = os.getenv("COSMOS_KEY")
COSMOS_DB_NAME = os.getenv("DATABASE_NAME")
COSMOS_CONTAINER_NAME = os.getenv("CONTAINER_NAME")

# Connect to existing database and container
cosmos_client = CosmosClient(COSMOS_ENDPOINT, COSMOS_KEY)
database = cosmos_client.get_database_client(COSMOS_DB_NAME)
container = database.get_container_client(COSMOS_CONTAINER_NAME)


def save_message(session_id: str, role: str, content: str, embedding: list = None):
    item = {
        "id": f"{session_id}_{role}_{os.urandom(4).hex()}",
        "session_id": session_id,
        "role": role,
        "content": content,
    }
    if role == "user" and embedding is not None:
        item["embedding"] = embedding
    container.upsert_item(item)


def cosine_similarity(vec1: list, vec2: list) -> float:
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    return float(np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2)))


def get_semantically_similar_answer(
    question: str,
    session_id: str,
    query_embedding: list[float],
    threshold: float = 0.95,
) -> str | None:
    query = f"""
    SELECT * FROM c 
    WHERE c.session_id = '{session_id}' AND c.role = 'user' AND IS_DEFINED(c.embedding)
    """
    user_messages = list(
        container.query_items(query, enable_cross_partition_query=True)
    )

    best_score = 0.0
    best_match = None

    for user_msg in user_messages:
        similarity = cosine_similarity(query_embedding, user_msg["embedding"])
        if similarity > best_score:
            best_score = similarity
            best_match = user_msg

    if best_match and best_score >= threshold:
        match_ts = best_match["_ts"]
        response_query = f"""
        SELECT * FROM c 
        WHERE c.session_id = '{session_id}' AND c.role = 'assistant' AND c._ts > {match_ts}
        ORDER BY c._ts ASC
        """
        answers = list(
            container.query_items(response_query, enable_cross_partition_query=True)
        )
        if answers:
            print(f"\n[Reused previous answer (score: {best_score:.3f})]")
            return answers[0]["content"]

    return None


def get_conversation_history(session_id: str) -> List:
    query = f"SELECT * FROM c WHERE c.session_id = '{session_id}' ORDER BY c._ts"
    items = list(container.query_items(query, enable_cross_partition_query=True))
    messages = []
    for item in items:
        if item["role"] == "user":
            messages.append(HumanMessage(content=item["content"]))
        elif item["role"] == "assistant":
            messages.append(AIMessage(content=item["content"]))
    return messages


def get_history_str(session_id: str) -> str:
    history = get_conversation_history(session_id)
    return "\n".join([f"{msg.type.capitalize()}: {msg.content}" for msg in history])


def format_chat_history(history: List) -> str:
    """
    Converts a list of LangChain HumanMessage and AIMessage objects into a readable string.
    """
    formatted = []
    for msg in history:
        if isinstance(msg, HumanMessage):
            formatted.append(f"User: {msg.content}")
        elif isinstance(msg, AIMessage):
            formatted.append(f"Assistant: {msg.content}")
    return "\n".join(formatted)


def get_cached_answer(question: str, session_id: str) -> str | None:
    query = f"""
    SELECT * FROM c
    WHERE c.session_id = '{session_id}' AND c.role = 'user' AND c.content = @question
    """
    parameters = [{"name": "@question", "value": question}]
    items = list(
        container.query_items(
            query, parameters=parameters, enable_cross_partition_query=True
        )
    )

    if not items:
        return None

    user_entry = items[0]
    query_ts = user_entry["_ts"]

    answer_query = f"""
    SELECT * FROM c
    WHERE c.session_id = '{session_id}' AND c.role = 'assistant' AND c._ts > {query_ts}
    ORDER BY c._ts ASC
    """
    answer_items = list(
        container.query_items(answer_query, enable_cross_partition_query=True)
    )
    if answer_items:
        return answer_items[0]["content"]
    return None


def store_new_document_from_web(
    session_id: str, documents: List[Document], original_question: str
):
    """
    Store the user's original question and the web search-based response in Cosmos DB.
    This ensures both are available for future semantic matching.
    """
    # Generate embedding for the user's question
    embedding = generate_query_embedding(original_question)

    # 1. Store the user question with embedding
    user_item = {
        "id": f"{session_id}_user_web_{os.urandom(4).hex()}",
        "session_id": session_id,
        "role": "user",
        "content": original_question,
        "embedding": embedding,
    }
    container.upsert_item(user_item)

    # 2. Store the assistant's web-generated answer(s)
    for document in documents:
        assistant_item = {
            "id": f"{session_id}_web_{os.urandom(4).hex()}",
            "session_id": session_id,
            "role": "assistant",
            "content": document.page_content,
            "metadata": document.metadata,
        }
        container.upsert_item(assistant_item)

def get_exact_match_answer(question: str, session_id: str) -> str | None:
    query = """
    SELECT c.timestamp, c.role, c.content
    FROM c
    WHERE c.session_id = @session_id
    ORDER BY c.timestamp ASC
    """
    params = [{"name": "@session_id", "value": session_id}]
    results = list(container.query_items(query, parameters=params, enable_cross_partition_query=True))

    # Go through chat history, find exact match
    for i in range(len(results) - 1):
        user_msg = results[i]
        assistant_msg = results[i + 1]

        if (
            user_msg["role"] == "user"
            and assistant_msg["role"] == "assistant"
            and user_msg["content"].strip().lower() == question.strip().lower()
        ):
            return assistant_msg["content"]

    return None



from langchain.prompts import PromptTemplate
from langchain.chains.llm import LLMChain

SUMMARY_PROMPT = PromptTemplate.from_template("""
You are an AI assistant. Given the conversation history below, summarize it in a concise paragraph that captures the key context and user goals. Keep it under 100 words.

Chat History:
-------------
{history}

Summary:
""")

def summarize_history_with_llm(llm, history_str: str) -> str:
    chain = LLMChain(llm=llm, prompt=SUMMARY_PROMPT)
    result = chain.invoke({"history": history_str})
    return result["text"].strip()

