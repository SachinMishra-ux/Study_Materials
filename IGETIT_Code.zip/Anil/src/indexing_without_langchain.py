import os
import uuid
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from langchain_openai import AzureOpenAIEmbeddings
from langchain.schema import Document
from typing import List
from src.index_helper import validate_documents, get_azure_openai_embeddings

# from data_loader import split_documents, load_documents_from_blob
from src.new_data_loader import split_documents, load_documents_from_blob
from src.data_preprocessing import clean_html_documents, clean_json_txt_documents
from src.constants import CONTAINERS, ACCOUNT, INDEX_NAME

os.environ["TIKTOKEN_CACHE_DIR"] = (
    r"C:\Users\smm931389\Desktop\IGETITV2-Learner-ChatBot-API\cl100k_base.tiktoken"
)

from azure.core.pipeline.transport import RequestsTransport

transport = RequestsTransport(connection_verify=False)


# Function to build sample documents (adjust as needed)
# ------------------------------
def build_search_documents(embedded_docs: List[dict]) -> List[dict]:
    """
    Transforms a list of documents with embeddings into a format suitable for Azure Search.

    Args:
        embedded_docs: A list of dictionaries, where each dictionary represents a document
                       and contains 'text', 'metadata', and 'embedding' keys.

    Returns:
        A list of dictionaries, where each dictionary is formatted for Azure Search,
        including an 'id', 'content', 'source', and 'content_vector'.
    """
    azure_docs = []
    for doc in embedded_docs:
        indexed_doc = {
            "id": str(uuid.uuid4()),
            "content": doc["text"],
            "source": doc.get("metadata", {}).get("source", "unknown"),
            "content_vector": doc["embedding"],
        }
        azure_docs.append(indexed_doc)
    return azure_docs


def generate_embeddings_for_docs(split_docs: List[Document]) -> List[dict]:
    """
    Generates embeddings for a list of LangChain documents using Azure OpenAI.

    Args:
        split_docs: A list of LangChain Document objects.

    Returns:
        A list of dictionaries, where each dictionary contains the document text,
        metadata, and its corresponding embedding.  Returns an empty list on error.
    """

    embedder = get_azure_openai_embeddings()
    if embedder is None:
        print("Error: Could not initialize Azure OpenAI embeddings.")
        return []  # Return an empty list to indicate failure, handle it

    texts = [doc.page_content for doc in split_docs]
    embeddings = embedder.embed_documents(texts)

    embedded_docs = []
    for doc, embedding in zip(split_docs, embeddings):
        embedded_docs.append(
            {"text": doc.page_content, "metadata": doc.metadata, "embedding": embedding}
        )
    return embedded_docs


# Function to upload validated documents


def upload_documents_to_azure(
    index_name: str, documents: list, endpoint: str, api_key: str
) -> None:
    """
    Uploads a list of documents to an Azure Search index.

    Args:
        index_name: The name of the Azure Search index.
        documents: A list of documents to upload, formatted for Azure Search.
        endpoint: The endpoint URL of the Azure Search service.
        credential: AzureKeyCredential object for authentication.

    Raises:
        Exception: If the document validation fails.
    """
    credential = AzureKeyCredential(api_key)
    client = SearchClient(
        endpoint=endpoint,
        index_name=index_name,
        credential=credential,
        transport=transport,
    )

    # Validate the documents before attempting to upload.  This is crucial.
    validate_documents(documents)
    result = client.upload_documents(documents=documents)

    for r in result:
        if not r.succeeded:
            print(
                f"❌ Failed to upload doc {r.key if isinstance(r.key, str) else '[no-key]'}: {r.error_message}"
            )
        else:
            print(f"✅ Uploaded doc {r.key}")


# Example usage (after your `split_documents` logic):
if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv()

    endpoint = os.getenv("AZURE_SEARCH_ENDPOINT")
    api_key = os.getenv("AZURE_SEARCH_KEY")

    docs = load_documents_from_blob(CONTAINERS, ACCOUNT)
    docs = clean_html_documents(docs)
    docs = clean_json_txt_documents(docs)
    split_docs = split_documents(docs)

    embedded_docs = generate_embeddings_for_docs(split_docs)
    azure_docs = build_search_documents(embedded_docs)
    print(azure_docs[0])

    upload_documents_to_azure(INDEX_NAME, azure_docs, endpoint, api_key)
