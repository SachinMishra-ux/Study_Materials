from bs4 import BeautifulSoup
from langchain.schema import Document
import chardet
from typing import List
from pptx import Presentation
import re

import json


def clean_html_documents(documents: List[Document]) -> List[Document]:
    """
    Cleans HTML content in LangChain Documents using BeautifulSoup.
    Strips scripts/styles/headers/etc. and keeps visible, readable text.
    """
    cleaned_docs = []

    for doc in documents:
        if doc.metadata.get("source", "").endswith(".html"):
            soup = BeautifulSoup(doc.page_content, "html.parser")

            # Remove unwanted tags
            for tag in soup(["script", "style", "footer", "nav", "noscript", "svg"]):
                tag.decompose()

            # Extract cleaned text
            visible_text = soup.get_text(separator="\n", strip=True)

            cleaned_doc = Document(page_content=visible_text, metadata=doc.metadata)
            cleaned_docs.append(cleaned_doc)
        else:
            cleaned_docs.append(doc)

    return cleaned_docs


def load_and_clean_html_from_blob(blob_data: bytes, blob_url: str) -> List[Document]:
    """
    Loads and cleans HTML content from blob data using BeautifulSoup.

    Args:
        blob_data (bytes): Raw HTML blob data.
        blob_url (str): URL or identifier for metadata.

    Returns:
        List[Document]: A list with a single cleaned LangChain Document.
    """
    print("🧹 Cleaning HTML content with BeautifulSoup...")

    # Detect encoding
    detected = chardet.detect(blob_data)
    encoding = detected["encoding"] or "utf-8"
    print(f"🔍 Detected encoding: {encoding}")

    try:
        html_content = blob_data.decode(encoding, errors="ignore")
        soup = BeautifulSoup(html_content, "html.parser")

        # Remove unnecessary tags
        for tag in soup(
            [
                "script",
                "style",
                "header",
                "footer",
                "nav",
                "form",
                "noscript",
                "svg",
                "aside",
            ]
        ):
            tag.decompose()

        # Get visible text and clean it
        visible_text = soup.get_text(separator="\n")
        cleaned_text = "\n".join(
            line.strip() for line in visible_text.splitlines() if line.strip()
        )

        print("✅ HTML cleaned successfully.")
        return [Document(page_content=cleaned_text, metadata={"source": blob_url})]

    except Exception as e:
        print(f"❌ Error while processing HTML: {e}")
        return []


def extract_text_from_structured_json(text: str) -> str:
    """
    Extracts text content from a JSON string with a specific structure.

    This function parses a JSON string, extracts text from the "SectionList" structure,
    cleans the HTML content within the "ContentList" items, and joins the extracted
    text with newlines.  If the JSON parsing fails, it returns the original text.

    Args:
        text: A string containing JSON data with a "SectionList" structure.
              The "SectionList" is expected to contain a list of sections,
              each with a "Title" and a "ContentList".  The "ContentList"
              is expected to contain items with "Primary" and "Secondary"
              HTML content.

    Returns:
        A string containing the extracted and cleaned text, joined by newlines,
        or the original text if parsing fails.
    """
    try:
        parsed = json.loads(text)
        sections = parsed.get("SectionList", [])  # Get the list of sections

        clean_parts = []  # List to store the extracted and cleaned text parts

        for section in sections:
            title = section.get("Title", "")  # Get the title of the section
            if title:
                clean_parts.append(
                    title.strip()
                )  # Add the title, stripped of extra spaces

            for item in section.get("ContentList", []):
                for key in ["Primary", "Secondary"]:
                    html_content = item.get(key, "")
                    if html_content:
                        # Clean HTML
                        soup = BeautifulSoup(html_content, "html.parser")
                        visible_text = soup.get_text(separator=" ", strip=True)
                        if visible_text:
                            clean_parts.append(visible_text)

        return "\n\n".join(clean_parts)
    except Exception as e:
        print(f"Error parsing structured JSON content: {e}")
        return text  # fallback to raw text


def clean_json_txt_documents(documents: List[Document]) -> List[Document]:
    """
    Cleans documents that contain structured JSON content within a .txt file.

    This function identifies documents that are .txt files and contain a specific
    JSON structure (indicated by the presence of '"SectionList":').  It then
    uses the `extract_text_from_structured_json` function to extract and clean
    the text content from the JSON structure.  Non-JSON .txt files and other
    document types are left unchanged.

    Args:
        documents: A list of LangChain Document objects.

    Returns:
        A new list of LangChain Document objects, where the text content of
        JSON-containing .txt files has been cleaned.
    """
    cleaned_docs = []

    for doc in documents:
        source = doc.metadata.get("source", "")
        if source.endswith(".txt") and '"SectionList":' in doc.page_content:
            # Extract and clean text from the structured JSON content
            cleaned_text = extract_text_from_structured_json(doc.page_content)
            cleaned_docs.append(
                Document(page_content=cleaned_text, metadata=doc.metadata)
            )
        else:
            cleaned_docs.append(doc)

    return cleaned_docs


def parse_srt_with_timestamps(file_path: str, source_url: str = "") -> List[Document]:
    """
    Custom SRT parser that retains timestamps and returns each subtitle as a Document.

    Args:
        file_path (str): Local path to the downloaded .srt file.
        source_url (str): Optional Azure Blob URL for metadata.

    Returns:
        List[Document]: List of parsed subtitle chunks.
    """
    documents = []

    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()

    # Split by double newlines (block separation)
    blocks = re.split(r"\n\s*\n", content.strip())

    for block in blocks:
        lines = block.strip().split("\n")
        if len(lines) >= 3:
            # Standard SRT format: [index], [timestamp], [text...]
            timestamp_line = lines[1]
            text_lines = lines[2:]
            text = " ".join(text_lines).strip()
            content_with_time = f"{timestamp_line}: {text}"

            doc = Document(
                page_content=content_with_time,
                metadata={"source": source_url, "timestamp": timestamp_line},
            )
            documents.append(doc)

    return documents


def load_pptx_as_documents(file_path: str, source_url: str = "") -> List[Document]:
    """
    Load a PowerPoint (.pptx) file and return a list of Documents, one per slide.
    """
    prs = Presentation(file_path)
    documents = []

    for i, slide in enumerate(prs.slides):
        texts = []
        for shape in slide.shapes:
            if hasattr(shape, "text"):
                texts.append(shape.text.strip())
        slide_text = "\n".join(filter(None, texts)).strip()

        if slide_text:
            documents.append(
                Document(
                    page_content=slide_text,
                    metadata={"source": source_url, "slide_number": i + 1},
                )
            )

    return documents
