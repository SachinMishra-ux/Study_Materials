from typing import TypedDict, List, Optional, Callable
from langchain.schema import Document
from langgraph.graph import StateGraph, END

from src.web_utils import fetch_web_documents
from src.cosmos_helper import (
    get_conversation_history,
    format_chat_history,
    get_exact_match_answer,
    summarize_history_with_llm,
    save_message,
)
from src.new_llm_module import (
    build_rag_chain,
    build_history_only_chain,
    initialize_llm,
    get_relevant_documents,
)

# === Initialize LLM and chains ===
_llm = initialize_llm()
_rag_chain = build_rag_chain(_llm)
_history_chain = build_history_only_chain(_llm)

# === State definition ===
class RAGState(TypedDict):
    question: str
    session_id: str
    chat_history: str
    documents: List[Document]
    answer: Optional[str]
    next: Optional[str]
    web_searched: Optional[bool]
    from_cache: Optional[bool]
    log_callback: Optional[Callable[[str], None]]
    early_answer_callback: Optional[Callable[[str], None]]  # 👈 New callback for early response

# === Utility ===
def log(state: RAGState, message: str):
    if callback := state.get("log_callback"):
        callback(message)

# === Nodes ===
def check_cache_node(state: RAGState):
    log(state, "🧠 Checking exact match cache...")
    cached_answer = get_exact_match_answer(
        question=state["question"],
        session_id=state["session_id"],
    )
    if cached_answer:
        log(state, "✅ Found exact match in cache.")
        return {"answer": cached_answer, "from_cache": True, "next": "END"}
    log(state, "❌ No exact match found in cache.")
    return {"next": "summarize_history"}

def summarize_history_node(state: RAGState):
    log(state, "📜 Fetching and summarizing chat history...")

    history = get_conversation_history(state["session_id"])

    if len(history) <= 6:
        formatted = format_chat_history(history)
        log(state, "📝 Short history (<= 3 turns), using it directly.")
        return {"chat_history": formatted, "next": "check_history_answer"}

    # Define limits
    recent_turns = 3  # 3 most recent turns = 6 messages
    summary_turns = 5  # 5 turns before that = 10 messages

    recent_messages = history[-2 * recent_turns:]  # last 6 messages
    summary_messages = history[-2 * (recent_turns + summary_turns):-2 * recent_turns]  # previous 10 messages

    if summary_messages:
        summary_prompt = (
            "You are a helpful assistant. Summarize the following earlier chat history "
            "between a user and assistant, preserving all technical terms and context:\n\n"
            f"{format_chat_history(summary_messages)}"
        )
        summary_response = _llm.invoke(summary_prompt)
        summary_text = getattr(summary_response, "content", str(summary_response)).strip()
        log(state, f"📝 Summary of previous 5 turns: {summary_text[:100]}...")
    else:
        summary_text = ""

    recent_text = format_chat_history(recent_messages)
    combined_history = f"{summary_text}\n\nRecent conversation:\n{recent_text}" if summary_text else recent_text

    return {"chat_history": combined_history, "next": "check_history_answer"}

def check_history_answer_node(state: RAGState):
    log(state, "🤔 Checking if chat history has an answer...")
    result = _history_chain.invoke({
        "question": state["question"],
        "chat_history": state.get("chat_history", ""),
        "context": [],
    })
    answer_text = getattr(result, "content", str(result)).strip()
    if "internal docs are not sufficient" in answer_text.lower():
        log(state, "⚠️ History not enough. Moving to internal doc search.")
        return {"next": "check_docs"}

    log(state, "✅ Answer found from history.")
    save_message(state["session_id"], "user", state["question"])
    save_message(state["session_id"], "assistant", answer_text)
    return {"answer": answer_text, "next": "END"}

def check_docs_node(state: RAGState):
    log(state, "📚 Searching internal documents...")
    if state.get("web_searched"):
        return {"next": "generate_answer"}

    docs = get_relevant_documents(state["question"])
    if docs:
        log(state, f"✅ Found {len(docs)} relevant documents.")
        return {"documents": docs, "next": "generate_answer"}

    log(state, "❌ No relevant internal docs. Falling back to web search.")
    return {"next": "web_search"}

def web_search_node(state: RAGState):
    log(state, "🌐 Performing web search...")
    docs = fetch_web_documents(state["question"], _llm)
    if docs:
        log(state, f"✅ Web search found {len(docs)} documents.")
        return {"documents": docs, "web_searched": True, "next": "generate_answer"}
    log(state, "❌ Web search failed to find relevant content.")
    return {
        **state,
        "answer": "❌ I couldn't find anything relevant on the web either.",
        "web_searched": True,
        "next": "END",
    }

def generate_answer_node(state: RAGState):
    log(state, "📝 Generating answer...")
    docs = state.get("documents", [])
    save_message(state["session_id"], "user", state["question"])

    if state.get("web_searched") and docs:
        web_answer = docs[0].page_content.strip()
        log(state, "✅ Using web search result as answer.")
        save_message(state["session_id"], "assistant", web_answer)
        return {**state, "answer": web_answer, "next": "END"}

    result = _rag_chain.invoke({
        "question": state["question"],
        "chat_history": state["chat_history"],
        "context": docs,
    })
    answer_text = getattr(result, "content", str(result)).strip()

    incomplete_trigger = "internal docs are not sufficient"
    if incomplete_trigger in answer_text.lower() and not state.get("web_searched"):
        log(state, "⚠️ Incomplete answer detected. Triggering web search...")

        if state.get("early_answer_callback"):
            state["early_answer_callback"](answer_text)

        save_message(state["session_id"], "assistant", answer_text)
        return {**state, "answer": answer_text, "next": "web_search"}

    log(state, "✅ Final answer generated.")
    save_message(state["session_id"], "assistant", answer_text)
    return {**state, "answer": answer_text, "next": "END"}

# === Graph builder ===
def build_agentic_rag_graph():
    wf = StateGraph(state_schema=RAGState)

    wf.add_node("check_cached_answer", check_cache_node)
    wf.add_node("summarize_history", summarize_history_node)
    wf.add_node("check_history_answer", check_history_answer_node)
    wf.add_node("check_docs", check_docs_node)
    wf.add_node("web_search", web_search_node)
    wf.add_node("generate_answer", generate_answer_node)

    wf.set_entry_point("check_cached_answer")

    wf.add_conditional_edges(
        "check_cached_answer",
        path=lambda s: s["next"],
        path_map={"summarize_history": "summarize_history", "END": END},
    )
    wf.add_conditional_edges(
        "summarize_history",
        path=lambda s: s["next"],
        path_map={"check_history_answer": "check_history_answer"},
    )
    wf.add_conditional_edges(
        "check_history_answer",
        path=lambda s: s["next"],
        path_map={"check_docs": "check_docs", "END": END},
    )
    wf.add_conditional_edges(
        "check_docs",
        path=lambda s: s["next"],
        path_map={"generate_answer": "generate_answer", "web_search": "web_search"},
    )
    wf.add_edge("web_search", "generate_answer")
    wf.add_conditional_edges(
        "generate_answer",
        path=lambda s: s["next"],
        path_map={"web_search": "web_search", "END": END},
    )

    return wf.compile()

# === Pipeline runner ===
def run_rag_pipeline(
    question: str,
    session_id: str,
    compiled_graph,
    log_callback: Optional[Callable[[str], None]] = None,
    early_answer_callback: Optional[Callable[[str], None]] = None,
) -> str:
    initial_state: RAGState = {
        "question": question,
        "session_id": session_id,
        "chat_history": "",
        "documents": [],
        "answer": None,
        "next": None,
        "web_searched": False,
        "from_cache": False,
        "log_callback": log_callback,
        "early_answer_callback": early_answer_callback,
    }
    result = compiled_graph.invoke(initial_state)

    if isinstance(result, dict):
        return result.get("answer", "❌ No answer could be generated.")
    return "❌ Unexpected error: pipeline did not return valid state."

# === Optional CLI test ===
if __name__ == "__main__":
    compiled_graph = build_agentic_rag_graph()
    question = "What is the architecture of the Power Distribution Unit?"
    session_id = "test_session"

    def log(msg):
        print(f"> {msg}")

    def show_early(msg):
        print(f"\n⚠️ EARLY RESPONSE:\n{msg}\n")

    answer = run_rag_pipeline(
        question,
        session_id,
        compiled_graph,
        log_callback=log,
        early_answer_callback=show_early,
    )
    print("\n✅ Final Answer:", answer)
