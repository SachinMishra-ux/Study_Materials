# === llm_module.py ===
import os
import logging
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema.runnable import RunnableMap
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from typing import List
from langchain.schema import Document
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from azure.core.pipeline.transport import RequestsTransport

load_dotenv()

# Load environment variables
AZURE_LLM_DEPLOYMENT = os.getenv("AZURE_LLM_DEPLOYMENT")
AZURE_LLM_API_VERSION = os.getenv("AZURE_LLM_API_VERSION")
AZURE_LLM_OPENAI_ENDPOINT = os.getenv("AZURE_LLM_OPENAI_ENDPOINT")
AZURE_LLM_OPENAI_API_KEY = os.getenv("AZURE_LLM_OPENAI_API_KEY")
AZURE_SEARCH_ENDPOINT = os.getenv("AZURE_SEARCH_ENDPOINT")
AZURE_SEARCH_KEY = os.getenv("AZURE_SEARCH_KEY")
from src.constants import INDEX_NAME

AZURE_SEARCH_INDEX = INDEX_NAME

transport = RequestsTransport(connection_verify=False)

TEMPLATE = """
You are a helpful assistant for the IGEIT learning platform. Use the following extracted context and prior conversation history to answer the user's question.

Always include the **source** (e.g., document or video file name or URL). If the answer comes from a video transcript (.srt), also include the **exact timestamp(s)** from the transcript where the answer was found.

If multiple relevant sources or timestamps exist, summarize the best answer and list all related sources and timestamps.

If you think that the asked question can not be answered using the context or chat history then, respond with:
"🌐 Internal docs are not sufficient to answer the query, Running web search..."

Do not fabricate answers or include information not found in the context.

CONTEXT:
---------
{context}

CHAT HISTORY:
-------------
{chat_history}

QUESTION:
---------
{question}

Helpful Answer (always include source; include timestamp if from video transcript):
"""


prompt = ChatPromptTemplate.from_template(TEMPLATE)


def initialize_llm():
    logging.info("Initializing Azure Chat OpenAI")
    return AzureChatOpenAI(
        azure_deployment=AZURE_LLM_DEPLOYMENT,
        api_version=AZURE_LLM_API_VERSION,
        temperature=0,
        max_tokens=None,
        timeout=None,
        max_retries=2,
        azure_endpoint=AZURE_LLM_OPENAI_ENDPOINT,
        api_key=AZURE_LLM_OPENAI_API_KEY,
        streaming=True,
        callbacks=[
            StreamingStdOutCallbackHandler()
        ],  # Or your custom handler for UI updates
    )


def initialize_search_client():
    return SearchClient(
        endpoint=AZURE_SEARCH_ENDPOINT,
        index_name=AZURE_SEARCH_INDEX,
        credential=AzureKeyCredential(AZURE_SEARCH_KEY),
        transport=transport,
    )


def get_relevant_documents(query: str, top_k: int = 5) -> List[Document]:
    """
    Searches Azure Cognitive Search for relevant documents and returns LangChain-compatible Document objects.
    """
    try:
        client: SearchClient = initialize_search_client()
        results = client.search(query, top=top_k, select=["content", "source"])

        documents = []
        for result in results:
            content = result.get("content", "")
            source = result.get("source", "azure-search")
            if content:
                documents.append(
                    Document(page_content=content, metadata={"source": source})
                )
        return documents

    except Exception as e:
        print(f"❌ Error in get_relevant_documents: {e}")
        return []


def format_docs(docs):
    return "\n\n".join(
        [
            f"Content: {doc.page_content}\nSource: {doc.metadata.get('source', 'No source provided')}"
            for doc in docs
        ]
    )


def build_rag_chain(llm):
    return (
        RunnableMap(
            {
                "context": lambda inputs: format_docs(
                    get_relevant_documents(inputs["question"])
                ),
                "chat_history": lambda inputs: inputs.get("chat_history", ""),
                "question": lambda inputs: inputs["question"],
            }
        )
        | prompt
        | llm
    )
