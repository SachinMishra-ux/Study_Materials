import json
import ast
import uuid
from tqdm import tqdm
from embedding_setup import get_text_embedding  # your existing function

input_path = r"C:\Users\smm931389\Desktop\IGETITV2-Learner-ChatBot-API\Scripts\brocheure_syllabus.json"  # Replace with your actual file
output_path = r"Scripts\brochure_syllabus_updated_with_embeddings.json"

# === Step 1: Read and Parse File Robustly ===
def parse_json_file(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        raw = f.read()

    try:
        data = ast.literal_eval(raw)
        if isinstance(data, dict):
            return [data]
        elif isinstance(data, list):
            return data
    except Exception:
        pass

    # Try line-by-line for JSONL-style content
    docs = []
    for line in raw.splitlines():
        line = line.strip().rstrip(",")
        if not line:
            continue
        try:
            docs.append(json.loads(line))
        except json.JSONDecodeError:
            try:
                docs.append(ast.literal_eval(line))
            except Exception as e:
                print(f"Skipping malformed line: {line[:100]}... -> {e}")
    return docs

# === Step 2: Replace ID and Add Embedding ===
def process_and_embed(docs):
    for doc in tqdm(docs, desc="Generating embeddings"):
        # Replace existing 'id' with a new UUID
        doc["id"] = str(uuid.uuid4())

        text = doc.get("text_content", "")
        if text:
            doc["text_embedding"] = get_text_embedding(text)
        else:
            doc["text_embedding"] = []
    return docs

# === Step 3: Save Final JSON ===
def save_json(data, filepath):
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

# === Run All ===
if __name__ == "__main__":
    documents = parse_json_file(input_path)
    documents = process_and_embed(documents)
    save_json(documents, output_path)
    print(f"\n✅ UUIDs added, embeddings generated. File saved to: {output_path}")
