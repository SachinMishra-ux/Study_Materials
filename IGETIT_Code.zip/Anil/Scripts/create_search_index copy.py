from azure.identity import DefaultAzureCredential
from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SimpleField,
    SearchFieldDataType,
    SearchableField,
    SearchField,
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchProfile,
    SemanticConfiguration,
    SemanticPrioritizedFields,
    SemanticField,
    SemanticSearch,
    SearchIndex,
    AzureOpenAIVectorizer,
    AzureOpenAIVectorizerParameters
)
from azure.core.pipeline.transport import RequestsTransport
import os
from dotenv import load_dotenv
load_dotenv(override=True)

transport = RequestsTransport(connection_verify=False)
endpoint = os.getenv("AZURE_SEARCH_ENDPOINT")
credential = AzureKeyCredential(os.getenv("AZURE_SEARCH_KEY", "")) if len(os.getenv("AZURE_SEARCH_KEY", "")) > 0 else DefaultAzureCredential()
azure_openai_embedding_dimensions = int(os.getenv("AZURE_OPENAI_EMBEDDING_DIMENSIONS", 3072))
azure_openai_embedding_deployment= os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT")
azure_openai_endpoint= os.getenv("AZURE_OPENAI_ENDPOINT")
embedding_model_name= os.getenv("EMBEDDING_MODEL_NAME") 
azure_openai_key= os.getenv("AZURE_OPENAI_API_KEY")
index_name= os.getenv("INDEX_NAME")

# Create a search index
index_client = SearchIndexClient(
    endpoint=endpoint, credential=credential, transport= transport)
fields = [
    SimpleField(name="id", type=SearchFieldDataType.String, key=True, sortable=True, filterable=True, facetable=True),
    SimpleField(name="CourseID", type=SearchFieldDataType.Int32, filterable=True),
    SimpleField(name="DocID", type=SearchFieldDataType.Int32, filterable=True),
    SimpleField(name="BlobPath", type=SearchFieldDataType.String, filterable=True),
    SimpleField(name="SkillLevel", type=SearchFieldDataType.String, filterable=True),
    SimpleField(name="UnitTitle", type=SearchFieldDataType.String, filterable=True),
    SearchableField(name="CategoryName", type=SearchFieldDataType.String, filterable=True),
    SearchableField(name="SubCategoryName", type=SearchFieldDataType.String, filterable=True),
    SearchableField(name="CourseTitle", type=SearchFieldDataType.String, filterable=True),
    SearchableField(name="DocTitle", type=SearchFieldDataType.String, filterable=True),
    SearchableField(name="DocURL", type=SearchFieldDataType.String, filterable=True),

    # ✅ Change is here:
    SimpleField(name="SubscriptionIDs", type=SearchFieldDataType.Collection(SearchFieldDataType.String), filterable=True, searchable=False),

    SearchableField(name="text_content", type=SearchFieldDataType.String, filterable=True),
    SearchField(
        name="text_embedding",
        type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
        searchable=True,
        vector_search_dimensions=azure_openai_embedding_dimensions,
        vector_search_profile_name="myHnswProfile"
    )
]



# Configure the vector search configuration  
vector_search = VectorSearch(
    algorithms=[
        HnswAlgorithmConfiguration(
            name="myHnsw"
        )
    ],
    profiles=[
        VectorSearchProfile(
            name="myHnswProfile",
            algorithm_configuration_name="myHnsw",
            vectorizer_name="myVectorizer"
        )
    ],
    vectorizers=[
        AzureOpenAIVectorizer(
            vectorizer_name="myVectorizer",
            parameters=AzureOpenAIVectorizerParameters(
                resource_url=azure_openai_endpoint,
                deployment_name=azure_openai_embedding_deployment,
                model_name=embedding_model_name,
                api_key=azure_openai_key
            )
        )
    ]
)


semantic_config = SemanticConfiguration(
    name="my-semantic-config",
    prioritized_fields=SemanticPrioritizedFields(
        title_field=SemanticField(field_name="CourseTitle"),
        keywords_fields=[SemanticField(field_name="CategoryName")],
        content_fields=[SemanticField(field_name="text_content")]
    )
)

# Create the semantic settings with the configuration
semantic_search = SemanticSearch(configurations=[semantic_config])

# Create the search index with the semantic settings
index = SearchIndex(name=index_name, fields=fields,
                    vector_search=vector_search, semantic_search=semantic_search)
result = index_client.create_or_update_index(index)
print(f'{result.name} created')