import os
import json
from azure.storage.blob import ContainerClient
from bs4 import BeautifulSoup
from read_excel import get_blob_paths
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configuration
AZURE_STORAGE_CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = "course-docs"
BLOB_PATHS_TO_DOWNLOAD = get_blob_paths('.\Scripts\Data\EV_Courses.xlsx')
DOWNLOAD_DIR = "NX_Course"

def get_container_client():
    """Create Azure Blob ContainerClient with SSL verification disabled."""
    return ContainerClient.from_connection_string(
        conn_str=AZURE_STORAGE_CONNECTION_STRING,
        container_name=CONTAINER_NAME
    )

def download_blob(container_client, blob_path, download_dir):
    """Download a blob to a local file."""
    if blob_path.startswith(f"{CONTAINER_NAME}/"):
        blob_name = blob_path[len(f"{CONTAINER_NAME}/"):]
    else:
        blob_name = blob_path

    blob_client = container_client.get_blob_client(blob_name)
    local_path = os.path.join(download_dir, os.path.basename(blob_name))

    try:
        with open(local_path, "wb") as f:
            stream = blob_client.download_blob()
            f.write(stream.readall())
        print(f"✅ Downloaded: {blob_name} -> {local_path}")
        return local_path
    except Exception as e:
        print(f"❌ Failed to download {blob_name}: {e}")
        return None

def extract_paragraphs_and_images(json_data):
    """Extract <p> text and <img src=...> links from HTML inside JSON."""
    paragraphs = []
    image_sources = []

    for section in json_data.get("SectionList", []):
        for content in section.get("ContentList", []):
            html = content.get("Primary", "")
            soup = BeautifulSoup(html, "html.parser")

            for p_tag in soup.find_all("p"):
                text = p_tag.get_text(strip=True)
                if text:
                    paragraphs.append(text)

                img_tag = p_tag.find("img")
                if img_tag and img_tag.get("src"):
                    image_sources.append(img_tag["src"])

    return paragraphs, image_sources

def process_file(file_path):
    """Read a downloaded .txt file and extract data."""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            json_data = json.load(f)

        paragraphs, image_sources = extract_paragraphs_and_images(json_data)

        print("\n📄 Extracted Paragraphs:")
        for p in paragraphs:
            print("-", p)

        print("\n🖼️ Extracted Image Paths:")
        for img in image_sources:
            print("-", img)
    except Exception as e:
        print(f"❌ Failed to process file {file_path}: {e}")

   

if __name__ == "__main__":
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    container_client = get_container_client()

    for blob_path in BLOB_PATHS_TO_DOWNLOAD:
        local_file = download_blob(container_client, blob_path, DOWNLOAD_DIR)
        if local_file:
            process_file(local_file)


