'''
import streamlit as st
import requests
import json
from io import BytesIO

st.set_page_config(page_title="LLM Chat (Non-Streaming)", layout="wide")
st.title("💬 IGETIT AI Chat Assistant")

# Session state for chat history
if "messages" not in st.session_state:
    st.session_state.messages = []

# Session state for JWT token
if "jwt_token" not in st.session_state:
    st.session_state.jwt_token = ""

# === JWT Token Input ===
with st.sidebar:
    st.header("🔐 Authentication")
    st.session_state.jwt_token = st.text_input("Enter JWT Token", type="password")

    if st.session_state.jwt_token:
        st.success("Token loaded")
    else:
        st.warning("Please provide a valid JWT token")

# === Chat Input ===
user_input = st.chat_input("Ask a question...")
if user_input:
    if not st.session_state.jwt_token:
        st.error("JWT token is required. Please enter it in the sidebar.")
    else:
        st.session_state.messages.append({"role": "user", "content": user_input})

        with st.chat_message("user"):
            st.markdown(user_input)

        # Prepare payload
        payload = {"question": user_input}

        # Prepare headers with JWT Bearer token
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {st.session_state.jwt_token}"
        }

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                try:
                    # === Hit the /get_llm_answer API ===
                    response = requests.post(
                        "https://igetitv2-learner-api-dev.myigetit.com/chatbot/get_llm_answer",
                        headers=headers,
                        data=json.dumps(payload),
                        timeout=60
                    )

                    if response.status_code != 200:
                        st.error(f"API Error: {response.status_code} - {response.text}")
                    else:
                        result = response.json()
                        answer = result.get("answer", "")
                        metadata = result.get("metadata", [])

                        st.markdown(answer)
                        st.session_state.messages.append({"role": "assistant", "content": answer})

                        # === 🗣 Hit the /speak API ===
                        tts_response = requests.post(
                            "http://127.0.0.1:8000/speak",  # update if needed
                            headers={
                                "Content-Type": "application/json",
                                "Accept": "audio/mpeg"
                            },
                            json={"text": answer, "voice": "alloy"},
                            timeout=30
                        )

                        if tts_response.status_code == 200:
                            audio_data = BytesIO(tts_response.content)
                            st.audio(audio_data, format="audio/mp3")
                        else:
                            st.warning("TTS API Error: " + tts_response.text)

                        # === Show source metadata if present ===
                        if metadata:
                            st.markdown("#### 📎 Source Metadata")
                            for item in metadata:
                                st.json(item)

                except requests.exceptions.RequestException as e:
                    st.error(f"Connection Error: {e}")


'''




import streamlit as st
import sounddevice as sd
import numpy as np
import scipy.io.wavfile as wav
import tempfile
import requests
import json
import base64
from io import BytesIO

st.set_page_config(page_title="IGETIT AI Chat Assistant", layout="wide")
st.title("💬 IGETIT AI Chat Assistant")

# === Initialize session state ===
if "messages" not in st.session_state:
    st.session_state.messages = []

if "jwt_token" not in st.session_state:
    st.session_state.jwt_token = ""

# === Sidebar for JWT Token ===
with st.sidebar:
    st.header("🔐 Authentication")
    st.session_state.jwt_token = st.text_input("Enter JWT Token", type="password")

    if st.session_state.jwt_token:
        st.success("Token loaded")
    else:
        st.warning("Please provide a valid JWT token")


# === Function to handle LLM + TTS ===
def handle_user_query(user_input):
    st.session_state.messages.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    payload = {"question": user_input}
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {st.session_state.jwt_token}"
    }

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            try:
                llm_response = requests.post(
                    "http://127.0.0.1:8000/get_llm_answer",
                    headers=headers,
                    data=json.dumps(payload),
                    timeout=60
                )

                if llm_response.status_code != 200:
                    st.error(f"API Error: {llm_response.status_code} - {llm_response.text}")
                    return

                result = llm_response.json()
                answer = result.get("answer", "")
                metadata = result.get("metadata", [])

                st.markdown(answer)
                st.session_state.messages.append({"role": "assistant", "content": answer})

                # === TTS API ===
                tts_response = requests.post(
                    "http://127.0.0.1:8000/text_to_speech",
                    headers={
                        "Content-Type": "application/json",
                        "Accept": "audio/mpeg"
                    },
                    json={"text": answer, "voice": "alloy"},
                    timeout=60
                )

                if tts_response.status_code == 200:
                    audio_bytes = tts_response.content
                    b64_audio = base64.b64encode(audio_bytes).decode()

                    # Auto-play audio using HTML
                    st.markdown(
                        f"""
                        <audio autoplay>
                            <source src="data:audio/mp3;base64,{b64_audio}" type="audio/mp3">
                        </audio>
                        """,
                        unsafe_allow_html=True
                    )
                else:
                    st.warning("TTS API Error: " + tts_response.text)

                # === Metadata ===
                if metadata:
                    st.markdown("#### 📎 Source Metadata")
                    for item in metadata:
                        st.json(item)

            except requests.exceptions.RequestException as e:
                st.error(f"Connection Error: {e}")


# === Voice Recording ===
st.markdown("🎤 **Speak or type your question**")
duration = st.slider("Recording duration (seconds)", 1, 10, 5)

record = st.button("🎙 Record via Mic")
user_input = None

if record:
    st.info("Recording...")
    fs = 16000  # Sample rate
    try:
        recording = sd.rec(int(duration * fs), samplerate=fs, channels=1, dtype='int16')
        sd.wait()
        st.success("Recording complete!")

        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmpfile:
            wav.write(tmpfile.name, fs, recording)
            st.audio(tmpfile.name, format="audio/wav")

            # Transcribe using FastAPI
            st.info("Transcribing your voice input...")
            with open(tmpfile.name, "rb") as f:
                transcribe_response = requests.post(
                    "http://127.0.0.1:8000/transcribe",
                    files={"file": ("speech.wav", f, "audio/wav")},
                    timeout=60
                )

            if transcribe_response.status_code == 200:
                transcription = transcribe_response.json().get("text", "")
                if transcription:
                    st.markdown(f"🗣️ **You said:** `{transcription}`")
                    user_input = transcription
                else:
                    st.warning("Transcription returned empty.")
            else:
                st.error("Transcription API failed: " + transcribe_response.text)
    except Exception as e:
        st.error(f"Mic Recording Error: {e}")

# === Text Input ===
text_input = st.chat_input("Ask a question...")
if text_input:
    user_input = text_input

# === LLM + TTS Call ===
if user_input:
    if not st.session_state.jwt_token:
        st.error("JWT token is required. Please enter it in the sidebar.")
    else:
        handle_user_query(user_input)


