import os
from dotenv import load_dotenv
from Scripts.inference.llm_setup import (
    initialize_llm,
    get_relevant_documents,
    build_rag_chain
)
from Scripts.inference.utils import get_search_client
from Scripts.embedding_setup import get_azure_openai_embeddings
from Scripts.inference.web_search import fetch_web_documents
from typing import Optional

from langchain.agents import Tool, initialize_agent
from langchain.agents.agent_types import AgentType


from Scripts.inference.cosmos_helper import (
    get_conversation_history,
    format_chat_history,
    save_message,
)
from jose import jwt, JWTError
from typing import Optional




load_dotenv(override=True)

# Example: Load your JWT secret and algorithm from environment variables
JWT_SECRET = os.getenv("JWT_SECRET", "your-secret-key")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")


def load_env_variables():
    return {
        "azure_llm_deployment": os.getenv("AZURE_LLM_DEPLOYMENT"),
        "azure_llm_api_version": os.getenv("AZURE_LLM_API_VERSION"),
        "azure_llm_openai_endpoint": os.getenv("AZURE_LLM_OPENAI_ENDPOINT"),
        "azure_llm_api_key": os.getenv("AZURE_LLM_OPENAI_API_KEY"),
        "search_endpoint": os.getenv("AZURE_SEARCH_ENDPOINT"),
        "search_key": os.getenv("AZURE_SEARCH_KEY"),
        "index_name": os.getenv("INDEX_NAME")

    }



def initialize_clients(config):
    llm = initialize_llm(
        azure_deployment=config["azure_llm_deployment"],
        api_version=config["azure_llm_api_version"],
        azure_endpoint=config["azure_llm_openai_endpoint"],
        api_key=config["azure_llm_api_key"],
    )
    embedding_client = get_azure_openai_embeddings()
    search_client = get_search_client(
        endpoint=config["search_endpoint"],
        index_name=config["index_name"],
        api_key=config["search_key"]
    )
    return llm, embedding_client, search_client



def decode_jwt(token: str) -> Optional[str]:
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload.get("session_id")
    except JWTError as e:
        print(f"❌ Invalid JWT token: {e}")
        return None


def run_rag_pipeline(llm, embedding_client, search_client, question, session_id: str, user_id: str, metadata_filter=None):
    # Step 1: Retrieve chat history from Cosmos DB
    chat_history_objects = get_conversation_history(session_id)
    formatted_history = format_chat_history(chat_history_objects)
    
    # Step 2: Fetch internal documents
    documents = get_relevant_documents(
        search_client=search_client,
        embedding_client=embedding_client,
        query=question,
        metadata_filter=metadata_filter,
        top_k=4
    )

    # Step 3: Run prompt with chat history and documents
    rag_chain = build_rag_chain(llm)
    response = rag_chain.invoke({
        "question": question,
        "documents": documents,
        "chat_history": formatted_history
    })

    # Step 4: Store user question and get question_id
    question_id = save_message(
        session_id=session_id,
        role="user",
        content=question,
        user_id=user_id
    )

    # Step 5: Handle "[NEEDS_WEB_SEARCH]" fallback
    if "[NEEDS_WEB_SEARCH]" in response.content:
        try:
            query_to_search = response.content.split("[NEEDS_WEB_SEARCH]")[-1].strip()
            web_docs = fetch_web_documents(query=query_to_search, llm=llm)
            filtered_web_docs = [doc for doc in web_docs if doc.page_content.strip()]

            formatted_result = f"🌐 Here's what I found from the web about **{query_to_search}**:\n\n"
            for idx, doc in enumerate(filtered_web_docs, 1):
                content = doc.page_content.strip()
                source = doc.metadata.get("source", "")
                formatted_result += f"**Result {idx}:**\n{content}\n🔗 Source: {source}\n\n"

            answer_id = save_message(
                session_id=session_id,
                role="assistant",
                content=formatted_result,
                user_id=user_id
            )

            return {
                "question_id": question_id,
                "answer_id": answer_id,
                "answer": formatted_result,
                "sources": []
            }

        except Exception as e:
            error_message = f"❌ Web search failed: {str(e)}"
            answer_id = save_message(
                session_id=session_id,
                role="assistant",
                content=error_message,
                user_id=user_id
            )
            return {
                "question_id": question_id,
                "answer_id": answer_id,
                "answer": error_message,
                "sources": []
            }

    # Step 6: Prepare unique sources
    unique_sources = {}
    for doc in documents:
        doc_url = doc.metadata.get("DocURL")
        doc_title = doc.metadata.get("DocTitle")
        course_title = doc.metadata.get("CourseTitle")

        if doc_url and doc_url not in unique_sources:
            unique_sources[doc_url] = {
                "course_title": course_title,
                "doc_title": doc_title,
                "content": doc.page_content
            }

    sources = [
        {
            "doc_url": url,
            "course_title": data["course_title"],
            "doc_title": data["doc_title"],
            "content": data["content"]
        }
        for url, data in unique_sources.items()
    ]

    # Step 7: Store assistant response and get answer_id
    answer_id = save_message(
        session_id=session_id,
        role="assistant",
        content=response.content,
        user_id=user_id,
        sources=sources
    )

    return {
        "question_id": question_id,
        "answer_id": answer_id,
        "answer": response.content,
        "sources": sources
    }




def main(question: str, metadata_filter: dict = None,jwt_token: str = None):
    config = load_env_variables()

    llm, embedding_client, search_client = initialize_clients(config)
    
    # Decode the session_id from JWT
    session_id = decode_jwt(jwt_token)
    if not session_id:
        raise ValueError("Invalid or missing session_id in JWT")

    response = run_rag_pipeline(
        llm=llm,
        embedding_client=embedding_client,
        search_client=search_client,
        question=question,
        session_id=session_id,
        user_id="test-user123",
        metadata_filter=metadata_filter
    )

    print("\n🤖 Final LLM Answer:\n")
    print(response)

    # print("\n📎 Metadata for Display:\n")
    # for doc in documents:
    #     print(doc.metadata)

    return response


# Example usage
if __name__ == "__main__":

    sample_metadata_filter = {
    }

    # Dummy payload with session_id
    payload = {
        "session_id": "test-session-1234",
        "SubscriptionIDs":[]
    }

    # Create token
    jwt_token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    print("Dummy JWT Token:\n", jwt_token)
    while True:
        sample_question= input("Ask a question:")

        main(sample_question, sample_metadata_filter,jwt_token)


