from Scripts.inference.llm_setup import initialize_llm
import logging
from langchain_openai import AzureChatOpenAI
from langchain.schema import HumanMessage
import os

from dotenv import load_dotenv
# === Load .env ===
load_dotenv(override=True)

def get_course_intent_from_query(query: str, llm: AzureChatOpenAI) -> str:
    system_prompt = """
    You are an assistant that classifies user queries into one of three course categories: 'NX', 'CATIA', or 'EV'.
    If the query is not clearly related to any of these, respond with 'None'.
    Only respond with one of these four values: NX, CATIA, Electric Vehicle Design and Development, None.

    Examples:
    - "Tell me about electric vehicles" -> Electric Vehicle Design and Development
    - "What are the tools used in CATIA?" -> CATIA
    - "Explain assembly modeling in NX" -> NX
    - "Can you help me with something?" -> None

    Now classify the following query:
    """
    message = HumanMessage(content=system_prompt + query)

    try:
        response = llm([message])
        predicted_intent = response.content.strip()
        if predicted_intent in ["NX", "CATIA", "Electric Vehicle Design and Development", "None"]:
            return predicted_intent
        return "None"
    except Exception as e:
        logging.error(f"Error while classifying course intent: {e}")
        return "None"
    
if __name__=="__main__":
    azure_llm_deployment= os.getenv("AZURE_LLM_DEPLOYMENT")
    azure_llm_api_version = os.getenv("AZURE_LLM_API_VERSION")
    azure_llm_openai_endpoint = os.getenv("AZURE_LLM_OPENAI_ENDPOINT")
    azure_llm_api_key = os.getenv("AZURE_OPENAI_API_KEY")

    llm = initialize_llm(
    azure_deployment=azure_llm_deployment,
    api_version=azure_llm_api_version,
    azure_endpoint=azure_llm_openai_endpoint,
    api_key=azure_llm_api_key,
    )

    user_query = "What are the design tools used in electric vehicle engineering?"
    course_intent = get_course_intent_from_query(user_query, llm)
    print("Course Intent:", course_intent)

        