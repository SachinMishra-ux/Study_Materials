import requests
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv(override=True)

def text_to_speech_azure(text: str, output_file_path: str = "output.mp3", voice: str = "alloy") -> str:
    # Load necessary environment variables
    api_key = os.getenv("AZURE_TTS_KEY")
    endpoint = os.getenv("AZURE_TTS_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_TTS_MODEL_NAME", "gpt-4o-mini-tts")
    api_version = os.getenv("AZURE_TTS_API_VERSION", "2025-03-01-preview")

    # Validate
    if not all([api_key, endpoint, deployment, api_version]):
        raise ValueError("❌ Missing required environment variables for TTS.")

    # Build request URL
    url = f"{endpoint}/openai/deployments/{deployment}/audio/speech?api-version={api_version}"

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }

    payload = {
        "model": deployment,
        "input": text,
        "voice": voice
    }

    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()

        # Save audio file
        with open(output_file_path, "wb") as f:
            f.write(response.content)

        print(f"✅ Audio saved to {output_file_path}")
        return output_file_path

    except requests.exceptions.HTTPError as http_err:
        print(f"❌ HTTP error occurred: {http_err} - {response.text}")
    except Exception as err:
        print(f"❌ Unexpected error: {err}")

    return None

if __name__ == "__main__":
    audio_path = text_to_speech_azure("Hello, this is your AI Coach!", "ai_voice.mp3")
    if audio_path:
        print(f"Play this file: {audio_path}")
