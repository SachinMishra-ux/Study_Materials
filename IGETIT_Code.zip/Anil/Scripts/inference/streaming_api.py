from fastapi import FastAPI, HTTPException, Depends, UploadFile, File
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi import Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from typing import Dict, Any, Optional
from datetime import datetime, timedelta,timezone
import httpx
from jose import jwt, JWTError
from dotenv import load_dotenv, find_dotenv
from pydub import AudioSegment
import requests
import os
from jose.exceptions import ExpiredSignatureError, JWTClaimsError, JWTError

import io
from tempfile import NamedTemporaryFile

# === Load .env ===
load_dotenv(dotenv_path=find_dotenv(), override=True)

# === Bearer Scheme ===
bearer_scheme = HTTPBearer()

# === Global Session Store ===
session_store: Dict[str, Dict] = {}

# === Local imports ===
from Scripts.inference.llm_setup import initialize_llm, get_relevant_documents, build_rag_chain
from Scripts.inference.llm_response import run_rag_pipeline
from Scripts.inference.get_azure_vault_key import get_secret_from_key_vault
from Scripts.inference.cosmos_helper import get_structured_chat_history,get_sessions_by_user,delete_old_messages
from Scripts.inference.utils import get_search_client
from Scripts.embedding_setup import get_azure_openai_embeddings
from Scripts.inference.course_category_identification import get_course_intent_from_query

# === Environment Configuration ===
class Settings:
    def __init__(self):
        # === Azure Key Vault Config ===
        self.vault_url = os.getenv("VAULT_URL")
        self.secret_name = os.getenv("SECRET_NAME", "jwtKey")
        self.tenant_id = os.getenv("TENANT_ID")
        self.client_id = os.getenv("CLIENT_ID")
        self.client_secret = os.getenv("CLIENT_SECRET")

        self.app_env = os.getenv("APP_ENV", "dev").lower()

        self.jwt_secret = os.getenv("JWT_SECRET", "your-secret-key")
        self.jwt_algorithm = os.getenv("JWT_ALGORITHM", "HS256")

        # Dynamic session check URL based on env
        self.session_check_url = {
            "dev": os.getenv("SESSION_ACTIVE_URL_DEV"),
            "prod": os.getenv("SESSION_ACTIVE_URL_PROD"),
            "uat": os.getenv("SESSION_ACTIVE_URL_UAT")
        }.get(self.app_env)

        if not self.session_check_url:
            raise ValueError(f"Session check URL not defined for environment: {self.app_env}")


        # === Load JWT Secret from Key Vault ===
        self.jwt_secret = get_secret_from_key_vault(
            vault_url=self.vault_url,
            tenant_id=self.tenant_id,
            client_id=self.client_id,
            client_secret=self.client_secret,
            secret_name=self.secret_name
        )
        self.jwt_algorithm = os.getenv("JWT_ALGORITHM", "HS256")

        # === Other Settings ===
        self.azure_llm_deployment = os.getenv("AZURE_LLM_DEPLOYMENT")
        self.azure_llm_api_version = os.getenv("AZURE_LLM_API_VERSION")
        self.azure_llm_openai_endpoint = os.getenv("AZURE_LLM_OPENAI_ENDPOINT")
        self.azure_llm_api_key = os.getenv("AZURE_OPENAI_API_KEY")
        self.search_endpoint = os.getenv("AZURE_SEARCH_ENDPOINT")
        self.search_key = os.getenv("AZURE_SEARCH_KEY")
        self.index_name = os.getenv("INDEX_NAME")
        self.azure_tts_api_key = os.getenv("AZURE_TTS_KEY")
        self.azure_tts_endpoint = os.getenv("AZURE_TTS_OPENAI_ENDPOINT")
        self.azure_tts_model_name = os.getenv("AZURE_TTS_MODEL_NAME", "gpt-4o-mini-tts")
        self.azure_tts_api_version = os.getenv("AZURE_TTS_API_VERSION", "2025-03-01-preview")
        self.azure_stt_api_key = os.getenv("AZURE_STT_KEY")
        self.azure_stt_endpoint = os.getenv("AZURE_STT_OPENAI_ENDPOINT")
        self.azure_stt_model_name = os.getenv("AZURE_STT_MODEL_NAME", "whisper-1")
        self.azure_stt_api_version = os.getenv("AZURE_STT_MODEL_VERSION", "2023-09-01-preview")

try:
    config = Settings()
except ValueError as e:
    raise RuntimeError(f"Configuration error: {e}")

# === Initialize Clients ===
embedding_client = get_azure_openai_embeddings()
search_client = get_search_client(config.search_endpoint, config.index_name, config.search_key)
llm = initialize_llm(
    azure_deployment=config.azure_llm_deployment,
    api_version=config.azure_llm_api_version,
    azure_endpoint=config.azure_llm_openai_endpoint,
    api_key=config.azure_llm_api_key,
)

app = FastAPI(title="IGETIT Coach API",root_path="/chatbot")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# === Models ===
class QueryRequest(BaseModel):
    question: str = Field(..., min_length=5)

class QueryResponse(BaseModel):
    answer: str
    doc_urls: Optional[list[str]] = Field(default_factory=list)

class StoreContextRequest(BaseModel):
    SubscriptionIDs: list[str]

class TTSRequest(BaseModel):
    text: str
    voice: str = "alloy"

# === Routes ===
@app.get("/chatbot")
def read_root():
    return {"message": "App is up"}

@app.get("/health")
def health():
    return {"status": "ok"}

from time import time

@app.get("/generate_test_token")
def generate_test_token():
    try:
        now = int(time())  # current UNIX time
        exp = now + 3600   # 1 hour later

        payload = {
            "sub": "igetit2_AuthToken",
            "jti": "a76fb346-ec15-4cae-b224-d5c0143b519b",
            "iat": now,
            "exp": exp,
            "UserName": "KarthikReddy",
            "Email": "sfdgf@gmail.com",
            "UserId": "566765",
            "AccountId": "42345",
            "FirstName": "karthikreddy",
            "LastName": "Dev",
            "SessionId": "F92C6A04-EA58-4DA4-BFC4-3F3F2BBC80C3",
            "AccountTypeID": "14",
            "Currency": "INR",
            "UserTypeID": "1",
            "UserSource": "GA",
            "iss": "igetit2_dev",
            "aud": "igetit2_users"
        }

        token = jwt.encode(payload, config.jwt_secret, algorithm=config.jwt_algorithm)
        #print(f"[DEBUG] Generated Token: {token}")
        return {"token": token}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Token generation failed: {str(e)}")


@app.post("/store_user_context")
def store_user_context(
    body: StoreContextRequest,
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)
):
    try:
        token = credentials.credentials
        
        payload = jwt.decode(
            token,
            config.jwt_secret,
            algorithms=[config.jwt_algorithm],
            audience="igetit2_users",
            issuer="igetit2_dev",
        )

        session_id = payload.get("SessionId")
        user_id = payload.get("UserId")  # ✅ Extract UserId

        if not session_id or not user_id:
            raise HTTPException(status_code=400, detail="Missing session or user ID in token")

        session_store[session_id] = {
            "SubscriptionIDs": body.SubscriptionIDs,
            "UserId": user_id  # ✅ Store UserId in session_store
        }

        return {"success": True, "session_id": session_id, "user_id": user_id}

    except ExpiredSignatureError as e:
        print(f"[ERROR] Token expired: {e}")
        raise HTTPException(status_code=401, detail="Token expired")

    except JWTClaimsError as e:
        print(f"[ERROR] Invalid claims: {e}")
        raise HTTPException(status_code=401, detail=f"Invalid claims: {e}")

    except JWTError as e:
        print(f"[ERROR] JWT error: {e}")
        raise HTTPException(status_code=401, detail="Invalid or expired JWT token")

    except Exception as e:
        print(f"[ERROR] Other: {e}")
        raise HTTPException(status_code=500, detail=f"Error storing user context: {str(e)}")



@app.post("/get_llm_answer")
async def get_llm_answer(body: QueryRequest):
    try:
        # 🧠 Use the latest session stored (simulate "current session")
        if not session_store:
            raise HTTPException(status_code=403, detail="No session context found. Call /store_user_context first.")

        session_id, session_data = list(session_store.items())[-1]

        # ✅ Step 1: Call external isSessionActive API
        session_check_url = config.session_check_url

        async with httpx.AsyncClient() as client:
            response = await client.get(session_check_url, params={"SessionID": session_id})

        if response.status_code != 200:
            raise HTTPException(status_code=500, detail="Failed to validate session with external API")

        is_active = response.json().get("Data", False)
        if not is_active:
            raise HTTPException(status_code=401, detail="Session is inactive or expired")

        # ✅ Step 2: Proceed with LLM if session is active
        metadata_filter = {
            "SubscriptionIDs": session_data.get("SubscriptionIDs", [])
        }

        course_intent = get_course_intent_from_query(body.question, llm)
        if course_intent in ["NX", "CATIA", "Electric Vehicle Design and Development"]:
            metadata_filter["CategoryName"] = course_intent

        result = run_rag_pipeline(
            llm=llm,
            embedding_client=embedding_client,
            search_client=search_client,
            question=body.question,
            session_id=session_id,
            user_id=session_data.get("UserId"),
            metadata_filter=metadata_filter
        )

        return {
            "question_id": result["question_id"],
            "answer_id": result["answer_id"],
            "answer": result["answer"],
            "sources": result["sources"]
        }

    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting LLM answer: {str(e)}")



@app.get("/get_sessions_by_user")
async def fetch_sessions_by_user():
    try:
        if not session_store:
            raise HTTPException(status_code=403, detail="No session context found. Call /store_user_context first.")

        # Get latest session_id and session_data
        session_id, session_data = list(session_store.items())[-1]
        user_id = session_data.get("UserId")

        if not user_id:
            raise HTTPException(status_code=400, detail="UserId missing from session context")

        # ✅ Check if session is still active
        session_check_url = config.session_check_url
        async with httpx.AsyncClient() as client:
            response = await client.get(session_check_url, params={"SessionID": session_id})

        if response.status_code != 200:
            raise HTTPException(status_code=500, detail="Failed to validate session with external API")

        is_active = response.json().get("Data", False)
        if not is_active:
            raise HTTPException(status_code=401, detail="Session is inactive or expired")

        # ✅ Get sessions from Cosmos DB using user_id
        return get_sessions_by_user(user_id)

    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving sessions: {str(e)}")



@app.get("/chat_history/{session_id}")
async def get_chat_history(session_id: str):
    try:
        # ✅ Step 1: Get current session ID from global store for validation
        if not session_store:
            raise HTTPException(status_code=403, detail="No session context found. Call /store_user_context first.")
        
        current_session_id, _ = list(session_store.items())[-1]

        # ✅ Step 2: Validate if current session is active
        session_check_url = config.session_check_url
        async with httpx.AsyncClient() as client:
            response = await client.get(session_check_url, params={"SessionID": current_session_id})

        if response.status_code != 200:
            raise HTTPException(status_code=500, detail="Failed to validate session with external API")

        is_active = response.json().get("Data", False)
        if not is_active:
            raise HTTPException(status_code=401, detail="Session is inactive or expired")

        # ✅ Step 3: Fetch history for provided `session_id`
        history = get_structured_chat_history(session_id)
        if not history:
            return {"message": "No chat history found for the given session_id."}

        return history

    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve chat history: {str(e)}")


@app.delete("/cleanup_old_data")
def cleanup_old_data_endpoint(days: int = 7):
    """
    Endpoint to delete chat messages older than `days` (default = 7).
    """
    try:
        result = delete_old_messages(days=days)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cleanup failed: {str(e)}")


# === Main for Local Dev ===
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("Scripts.inference.streaming_api:app", host="0.0.0.0", port=8000)