# === llm_module.py ===

import logging
from typing import List
from langchain.schema import Document
from Scripts.inference.prompt_setup import get_prompt
from Scripts.inference.search_document import run_vector_search_with_filters
from Scripts.inference.utils import get_search_client
from langchain.schema.runnable import RunnableMap
from langchain_openai import AzureChatOpenAI
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from azure.search.documents import SearchClient

import os
from dotenv import load_dotenv
load_dotenv(override=True)




# === LLM Initialization ===
def initialize_llm(azure_deployment, api_version, azure_endpoint, api_key):
    logging.info("Initializing Azure Chat OpenAI")
    return AzureChatOpenAI(
        azure_deployment=azure_deployment,
        api_version=api_version,
        temperature=0,
        max_tokens=None,
        timeout=None,
        max_retries=2,
        azure_endpoint=azure_endpoint,
        api_key=api_key,
        streaming=True
    )



def get_relevant_documents(
    search_client,
    embedding_client,
    query: str,
    metadata_filter: dict = None,
    top_k: int = 4
) -> List[Document]:
    """
    Runs vector search, sends only text_content to LLM, preserves full metadata for final display.
    """
    try:
        results = run_vector_search_with_filters(
            search_client=search_client,
            embedding_client=embedding_client,
            query=query,
            metadata_filter=metadata_filter,
            top_k=top_k
        )

        documents = []
        for result in results:
            text = result.get("text_content", "").strip()
            if text:
                # Remove text_content from metadata to avoid duplication
                metadata = {k: v for k, v in result.items() if k != "text_content"}
                documents.append(
                    Document(
                        page_content=text,
                        metadata=metadata
                    )
                )
        return documents

    except Exception as e:
        print(f"❌ Error in get_relevant_documents: {e}")
        return []

'''
def format_docs(docs: List[Document]) -> str:
    return "\n\n---\n\n".join(doc.page_content for doc in docs if doc.page_content)

'''

def format_docs(docs: List[Document]) -> str:
    formatted = []
    for i, doc in enumerate(docs):
        doc_url = doc.metadata.get("DocURL", f"Doc_{i}")
        content = doc.page_content
        # Add clear source label, but NOT as a hyperlink
        formatted.append(f"Source: {doc_url}\n{content}")
    return "\n\n---\n\n".join(formatted)



### To see the prompt wwhich is sent to llm, uncomment this function. ###

def build_rag_chain(llm):
    # Compose the prompt stage
    inputs_mapper = RunnableMap(
    {
        "context": lambda inputs: format_docs(inputs["documents"]),
        "chat_history": lambda inputs: inputs.get("chat_history", ""),
        "question": lambda inputs: inputs["question"]
    }
    )

    prompt_template = get_prompt()

    def log_prompt(inputs):
        # Render the prompt manually before passing to LLM
        final_prompt = prompt_template.invoke(inputs)
        print("\n🔍 Final Prompt to LLM:\n" + "-" * 40)
        print(final_prompt)
        print("-" * 40 + "\n")
        return final_prompt

    return inputs_mapper | log_prompt | llm



'''
def build_rag_chain(llm):
    return (
        RunnableMap(
            {
                "context": lambda inputs: format_docs(inputs["documents"]),
                "chat_history": lambda inputs: inputs.get("chat_history", ""),
                "question": lambda inputs: inputs["question"],
            }
        )
        | get_prompt()
        | llm
    )
'''
