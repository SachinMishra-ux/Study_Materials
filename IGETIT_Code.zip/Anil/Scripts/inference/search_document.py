from azure.search.documents import SearchClient
from azure.search.documents import SearchItemPaged
from azure.search.documents.models import QueryType
from embedding_setup import get_azure_openai_embeddings
from Scripts.inference.utils import get_search_client
from typing import List, Optional

from azure.search.documents.models import (
    VectorizableTextQuery,
    VectorizedQuery,
    QueryType,
    QueryCaptionType,
    QueryAnswerType
)
import os
from dotenv import load_dotenv
load_dotenv(override=True)
# Helper code to print results




def search_and_print_results(
    endpoint: str,
    index_name: str,
    api_key: str,
    query: str,
    semantic_config: str = "my-semantic-config",
    top_k: int = 3
):
    search_client= get_search_client(endpoint,index_name,api_key)
    results: SearchItemPaged[dict] = search_client.search(
        search_text=query,
        query_type=QueryType.SEMANTIC,
        semantic_configuration_name=semantic_config,
        query_caption="extractive",
        query_answer="extractive",
        top=top_k
    )

    # Print semantic answers
    semantic_answers = results.get_answers()
    if semantic_answers:
        for answer in semantic_answers:
            print("🔍 Semantic Answer:")
            print(answer.highlights or answer.text)
            print(f"Score: {answer.score}\n")

    # Print individual results
    for result in results:
        print("🔹 Search Result:")
        print(f"ID: {result.get('id')}")
        print(f"BlobPath: {result.get('BlobPath')}")
        print(f"CategoryName: {result.get('CategoryName')}")
        print(f"SubCategoryName: {result.get('SubCategoryName')}")
        print(f"CourseID: {result.get('CourseID')}")
        print(f"CourseTitle: {result.get('CourseTitle')}")
        print(f"UnitTitle: {result.get('UnitTitle')}")
        print(f"DocID: {result.get('DocID')}")
        print(f"DocTitle: {result.get('DocTitle')}")
        print(f"SkillLevel: {result.get('SkillLevel')}")
        print(f"DocURL: {result.get('DocURL')}")
        print(f"SubscriptionIDs: {result.get('SubscriptionIDs')}")
        print(f"Score: {result.get('@search.score')}")
        if '@search.reranker_score' in result:
            print(f"Reranker Score: {result['@search.reranker_score']}")
        print()

        # Print caption if available
        captions = result.get("@search.captions")
        if captions:
            caption = captions[0]
            print("📌 Caption:")
            print(caption.highlights or caption.text)
            print()





def run_hybrid_search(
    search_client: SearchClient,
    query: str,
    vector_field: str = "contentVector",
    select_fields: Optional[List[str]] = None,
    top_k: int = 3,
    k_nearest_neighbors: int = 50
):
    """
    Runs a hybrid search (semantic + vector) using Azure Cognitive Search.

    Parameters:
        search_client (SearchClient): The initialized Azure SearchClient.
        query (str): The user's query string.
        vector_field (str): The name of the vector field in the index.
        select_fields (List[str], optional): Fields to include in the response.
        top_k (int): Number of top results to return.
        k_nearest_neighbors (int): Number of vector neighbors to use.

    Returns:
        SearchItemPaged: Search results from the index.
    """
    vector_query = VectorizableTextQuery(
        text=query,
        fields=vector_field,
        k_nearest_neighbors=k_nearest_neighbors
    )

    return search_client.search(
        search_text=query,
        vector_queries=[vector_query],
        select=select_fields or ["id", "CourseTitle", "DocTitle", "CategoryName", "text_content"],
        top=top_k
    )



def run_semantic_hybrid_search(
    search_client,
    query: str,
    vector_field: str = "text_embedding",
    select_fields: list = None,
    semantic_config_name: str = "my-semantic-config",
    top_k: int = 3,
    k_nearest_neighbors: int = 50
):
    """
    Perform semantic hybrid search on Azure AI Search index.

    Args:
        search_client: An instance of Azure `SearchClient`.
        query (str): The search query.
        vector_field (str): The vector field name to use for vector search.
        select_fields (list): List of fields to include in the results.
        semantic_config_name (str): Semantic configuration name.
        top_k (int): Number of top results to return.
        k_nearest_neighbors (int): Number of nearest neighbors to fetch in vector search.

    Returns:
        Search results iterator.
    """
    if select_fields is None:
        select_fields = ["id", "CourseTitle", "DocTitle", "text_content"]

    vector_query = VectorizableTextQuery(
        text=query,
        k_nearest_neighbors=k_nearest_neighbors,
        fields=vector_field,
        exhaustive=True
    )

    results = search_client.search(
        search_text=query,
        vector_queries=[vector_query],
        query_type=QueryType.SEMANTIC,
        semantic_configuration_name=semantic_config_name,
        query_caption=QueryCaptionType.EXTRACTIVE,
        query_answer=QueryAnswerType.EXTRACTIVE,
        select=select_fields,
        top=top_k
    )

    return results


def run_vector_search(
    search_client,
    embedding_client,
    query: str,
    vector_field: str = "text_embedding",
    select_fields: list = None,
    top_k: int = 3,
    k_nearest_neighbors: int = 50
):
    """
    Perform pure vector search on Azure Cognitive Search.

    Args:
        search_client: Azure SearchClient object.
        embedding_client: OpenAI or AzureOpenAI embedding client.
        query (str): User query to embed and search.
        embedding_model_name (str): Embedding model to use.
        embedding_dimensions (int): Dimensions of the embedding vector.
        vector_field (str): Name of the vector field in the search index.
        select_fields (list): List of fields to include in search results.
        top_k (int): Number of top results to return.
        k_nearest_neighbors (int): Number of nearest neighbors for vector search.

    Returns:
        Search results iterator.
    """
    if select_fields is None:
        select_fields = ["id", "CourseTitle", "DocTitle", "CategoryName", "text_content"]

    # Generate embedding using the embedding client
    embedding = embedding_client.embed_query(query)


    # Construct vectorized query
    vector_query = VectorizedQuery(
        vector=embedding,
        k_nearest_neighbors=k_nearest_neighbors,
        fields=vector_field
    )

    # Execute search
    results = search_client.search(
        search_text=None,
        vector_queries=[vector_query],
        select=select_fields,
        top=top_k
    )

    return results

def run_vector_search_with_filters(
    search_client,
    embedding_client,
    query: str,
    metadata_filter: dict = None,
    vector_field: str = "text_embedding",
    select_fields: list = None,
    top_k: int = 4,
    k_nearest_neighbors: int = 50,
    score_threshold: float = 0.59  # ✅ NEW PARAM
):
    """
    Perform pure vector search with metadata filtering and thresholding on search score.

    Args:
        search_client: Azure SearchClient object.
        embedding_client: OpenAI or AzureOpenAI embedding client.
        query (str): User query to embed and search.
        metadata_filter (dict): Dict of field-value pairs for filtering.
        vector_field (str): Name of the vector field.
        select_fields (list): List of fields to include in results.
        top_k (int): Number of results to return.
        k_nearest_neighbors (int): Number of neighbors in vector space.
        score_threshold (float): Minimum @search.score required to include result.

    Returns:
        List of parsed results (dicts) with score ≥ threshold.
    """
    if select_fields is None:
        select_fields = [
            "id", "BlobPath", "CategoryName", "SubCategoryName", "CourseID",
            "CourseTitle", "UnitTitle", "DocID", "DocTitle", "SkillLevel",
            "DocURL", "SubscriptionIDs", "text_content"
        ]

    # === Step 1: Generate Embedding
    embedding = embedding_client.embed_query(query)

    # === Step 2: Build Vector Query
    vector_query = VectorizedQuery(
        vector=embedding,
        k_nearest_neighbors=k_nearest_neighbors,
        fields=vector_field
    )

    # === Step 3: Build Filter Clause
    def build_filter_clause(metadata_filter: dict) -> str:
        clauses = []
        for key, value in metadata_filter.items():
            if key == "session_id":
                continue  # Skip session_id - not present in index

            if key == "SubscriptionIDs":
                valid_subs = [v.strip() for v in value if v and v.strip()]
                if valid_subs:
                    sub_filters = [f"{key}/any(s: s eq '{v}')" for v in valid_subs]
                    clauses.append(f"({' or '.join(sub_filters)})")

            elif key == "CategoryName" and isinstance(value, str):
                value = value.strip()
                if value:
                    # ✅ Partial match using `search.ismatch` for full-text filter
                    # NOTE: This only works if CategoryName is marked as searchable in your index
                    clauses.append(f"search.ismatch('{value}', 'CategoryName')")

            elif isinstance(value, str) and value.strip():
                clauses.append(f"{key} eq '{value.strip()}'")

            elif isinstance(value, (int, float)):
                clauses.append(f"{key} eq {value}")

            elif isinstance(value, list):
                valid_vals = [v for v in value if v]
                if valid_vals:
                    or_conditions = [f"{key} eq '{v}'" for v in valid_vals]
                    clauses.append(f"({' or '.join(or_conditions)})")

        return " and ".join(clauses) if clauses else None


    filter_clause = build_filter_clause(metadata_filter or {})
    print(f"🔍 Filter clause: {filter_clause}")

    # === Step 4: Perform Search
    search_results = search_client.search(
        search_text=None,
        vector_queries=[vector_query],
        select=select_fields,
        filter=filter_clause,
        top=top_k
    )

    # === Step 5: Filter & Parse Results
    parsed_results = []
    for result in search_results:
        score = result.get("@search.score", 0)
        if score < score_threshold:
            print(f"⚠️ Skipping result with low score: {score:.4f}")
            continue

        result_dict = {
            "id": result.get("id"),
            "BlobPath": result.get("BlobPath"),
            "Category": result.get("CategoryName"),
            "SubCategory": result.get("SubCategoryName"),
            "CourseID": result.get("CourseID"),
            "CourseTitle": result.get("CourseTitle"),
            "UnitTitle": result.get("UnitTitle"),
            "DocID": result.get("DocID"),
            "DocTitle": result.get("DocTitle"),
            "SkillLevel": result.get("SkillLevel"),
            "DocURL": result.get("DocURL"),
            "SubscriptionIDs": result.get("SubscriptionIDs"),
            "text_content": result.get("text_content"),
            "Score": score,
        }

        if result.get("@search.reranker_score"):
            result_dict["RerankerScore"] = result.get("@search.reranker_score")

        if result.get("@search.captions"):
            caption = result["@search.captions"][0]
            result_dict["Caption"] = caption.highlights or caption.text

        parsed_results.append(result_dict)

    return parsed_results









if __name__=="__main__":
    endpoint = os.getenv("AZURE_SEARCH_ENDPOINT")
    api_key = os.getenv("AZURE_SEARCH_KEY")
    index_name= os.getenv("INDEX_NAME")
    print(index_name)
    azure_openai_embedding_dimensions = int(os.getenv("AZURE_OPENAI_EMBEDDING_DIMENSIONS", 3072))
    
    embedding_model_name= os.getenv("EMBEDDING_MODEL_NAME") 
    search_client= get_search_client(endpoint,index_name,api_key)
    client= get_azure_openai_embeddings()
    
    # search_and_print_results(
    #     endpoint=endpoint,
    #     index_name=index_name,
    #     api_key=api_key,
    #     query="energy storage fundamentals"
    # )

    # query= "energy storage fundamentals"

    

    # results = run_hybrid_search(
    # search_client= search_client,
    # query="scalable storage solution",
    # vector_field="text_embedding",  # adjust if your vector field is named differently
    # select_fields=[
    #     "id", "BlobPath", "CategoryName", "SubCategoryName", "CourseID", "CourseTitle",
    #     "UnitTitle", "DocID", "DocTitle", "SkillLevel", "DocURL",
    #     "SubscriptionIDs", "text_content"
    # ],
    # top_k=3
    # )

    # print_results(results)


    # results = run_semantic_hybrid_search(
    #     search_client=search_client,
    #     query="what are the uses of Nickel metal hydride batteries?",
    #     vector_field="text_embedding",
    #     select_fields=[
    #         "id", "CourseTitle", "DocTitle", "CategoryName", "text_content"
    #     ],
    #     semantic_config_name="my-semantic-config",
    #     top_k=3
    # )

    # print_results(results)

    
    
    # results = run_vector_search(
    # search_client=search_client,
    # embedding_client=client,  # AzureOpenAI or OpenAI client
    # query="what are the uses of Nickel metal hydride batteries?",
    # vector_field="text_embedding",
    # select_fields=["id", "CourseTitle", "DocTitle", "CategoryName", "text_content"],
    # top_k=3
    # )

    # print_results(results)



    metadata = {
    "CategoryName": "Electric Vehicle Design and Development",
    "SubscriptionIDs": ["701", "702", "3010", "3011"]
    }

    results = run_vector_search_with_filters(
        search_client=search_client,
        embedding_client=client,
        query="what are the uses of Nickel metal hydride batteries?",
        metadata_filter=metadata,
        top_k=2
    )

    print(results)





