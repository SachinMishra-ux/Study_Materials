import os
import requests
import sounddevice as sd
from scipy.io.wavfile import write
from pydub import AudioSegment
from dotenv import load_dotenv
import tempfile

# Load environment variables
load_dotenv(override=True)

def record_audio(duration=5, fs=44100):
    print(f"🎙️ Recording {duration} seconds...")
    audio = sd.rec(int(duration * fs), samplerate=fs, channels=1, dtype='int16')
    sd.wait()
    temp_wav = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
    write(temp_wav.name, fs, audio)
    return temp_wav.name

def convert_to_mp3(wav_path):
    mp3_path = wav_path.replace(".wav", ".mp3")
    sound = AudioSegment.from_wav(wav_path)
    sound.export(mp3_path, format="mp3")
    return mp3_path

def transcribe_audio_azure(mp3_path):
    endpoint = os.getenv("AZURE_STT_OPENAI_ENDPOINT")
    api_key = os.getenv("AZURE_STT_KEY")
    deployment = os.getenv("AZURE_STT_MODEL_NAME", "gpt-4o-transcribe")
    api_version = os.getenv("AZURE_STT_MODEL_VERSION", "2025-03-01-preview")

    url = f"{endpoint}/openai/deployments/{deployment}/audio/transcriptions?api-version={api_version}"
    print(url)
    headers = {
        "Authorization": f"Bearer {api_key}"
    }

    with open(mp3_path, "rb") as f:
        files = {
            "file": (os.path.basename(mp3_path), f, "audio/mpeg"),
            "model": (None, deployment)
        }
        response = requests.post(url, headers=headers, files=files)

    if response.status_code == 200:
        result = response.json()
        print("✅ Transcription:", result["text"])
        return result["text"]
    else:
        print("❌ Transcription failed:", response.status_code, response.text)
        return None

if __name__ == "__main__":
    wav_file = record_audio(duration=5)
    mp3_file = convert_to_mp3(wav_file)
    transcribe_audio_azure(mp3_file)
