import os
import json
from azure.storage.blob import ContainerClient
from bs4 import BeautifulSoup
import re
from urllib.parse import urljoin
from read_excel import get_blob_paths
from embedding_setup import get_text_embedding
from dotenv import load_dotenv
from typing import Dict, Any, List, Tuple
from langchain.text_splitter import RecursiveCharacterTextSplitter

# Load environment variables
load_dotenv()

# Configuration
AZURE_STORAGE_CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = "course-docs"
BLOB_PATHS_TO_DOWNLOAD = get_blob_paths(os.path.join("Scripts", "Data", "CATIA_Courses.xlsx"))

DOWNLOAD_DIR = "CATIA_Course"
FINAL_OUTPUT_JSON = "CATIA_output.json"





def get_container_client():
    return ContainerClient.from_connection_string(
        conn_str=AZURE_STORAGE_CONNECTION_STRING,
        container_name=CONTAINER_NAME
    )

def download_blob(container_client, blob_path, download_dir):
    if blob_path.startswith(f"{CONTAINER_NAME}/"):
        blob_name = blob_path[len(f"{CONTAINER_NAME}/"):]
    else:
        blob_name = blob_path

    blob_client = container_client.get_blob_client(blob_name)
    local_path = os.path.join(download_dir, os.path.basename(blob_name))

    try:
        with open(local_path, "wb") as f:
            stream = blob_client.download_blob()
            f.write(stream.readall())
        print(f"✅ Downloaded: {blob_name} -> {local_path}")
        return local_path, blob_path
    except Exception as e:
        print(f"❌ Failed to download {blob_name}: {e}")
        return None, blob_path



def extract_text_images_pdfs_ppts(json_data):

    paragraphs = []
    image_sources = []
    pdf_paths = []
    ppt_paths = []

    # Regex patterns for raw URLs (catch edge cases not in <a> tags)
    url_pattern = re.compile(r'https?://[^\s"\']+\.(pdf|ppt|pptx)', re.IGNORECASE)
    base64_img_pattern = re.compile(r'^data:image\/[a-zA-Z]+;base64,')

    def parse_html_block(html):
        if not isinstance(html, str) or not html.strip():
            return

        soup = BeautifulSoup(html, "html.parser")

        # Extract visible text
        full_text = soup.get_text(separator="\n", strip=True)
        for line in full_text.split("\n"):
            line = line.strip()
            if line:
                paragraphs.append(line)

        # Extract images
        for img_tag in soup.find_all("img"):
            src = img_tag.get("src")
            if src:
                image_sources.append(src)

        # Extract links to PDFs and PPTs
        for tag in soup.find_all(["a", "embed", "iframe"]):
            href = tag.get("href") or tag.get("src")
            if href:
                href = href.strip()
                if href.lower().endswith(".pdf"):
                    pdf_paths.append(href)
                elif href.lower().endswith(".ppt") or href.lower().endswith(".pptx"):
                    ppt_paths.append(href)

        # Catch raw URLs to PDFs or PPTs that may not be inside tags
        raw_urls = url_pattern.findall(html)
        for match in url_pattern.finditer(html):
            url = match.group(0)
            if url.lower().endswith(".pdf"):
                pdf_paths.append(url)
            elif url.lower().endswith(".ppt") or url.lower().endswith(".pptx"):
                ppt_paths.append(url)

    time_pattern = re.compile(r"^\d+\s*(minutes|minute|hours|hour|secs|seconds)$", re.I)

    for section in json_data.get("SectionList", []):
        # Skip metadata sections like completion time
        if section.get("Title", "").lower() in ["completion time", "duration", "time"]:
            continue

        for content in section.get("ContentList", []):
            parse_html_block(content.get("Primary", ""))
            parse_html_block(content.get("Secondary", ""))
            for sub in content.get("SubContentList", []):
                parse_html_block(sub.get("Content", ""))
                parse_html_block(sub.get("Primary", ""))
                parse_html_block(sub.get("Secondary", ""))

    # Filter out timing info and very short lines
    filtered_paragraphs = [p for p in paragraphs if not time_pattern.match(p) and len(p) > 5]

    return filtered_paragraphs, image_sources, pdf_paths, ppt_paths

import re
from typing import Dict, Any, List, Tuple
from bs4 import BeautifulSoup

def get_data_metadata_embedding(json_data: Dict[str, Any]) -> Tuple[List[str], List[str], List[str], List[str]]:
    all_paragraphs = []
    image_sources = []
    pdf_paths = []
    ppt_paths = []
    all_embeddings = []

    url_pattern = re.compile(r'https?://[^\s"\']+\.(pdf|ppt|pptx)', re.IGNORECASE)
    time_pattern = re.compile(r"^\d+\s*(minutes|minute|hours|hour|secs|seconds)$", re.I)

    def extract_from_html_and_append(html: str, text_buffer: List[str]):
        if not isinstance(html, str) or not html.strip():
            return

        soup = BeautifulSoup(html, "html.parser")
        full_text = soup.get_text(separator=" ", strip=True)

        # Only append meaningful text
        if full_text and not time_pattern.match(full_text) and len(full_text.split()) > 5:
            text_buffer.append(full_text)

        # Extract image sources
        for img in soup.find_all("img"):
            src = img.get("src")
            if src:
                image_sources.append(src)

        # Extract embedded file URLs
        for tag in soup.find_all(["a", "embed", "iframe"]):
            href = tag.get("href") or tag.get("src")
            if href:
                if href.lower().endswith(".pdf"):
                    pdf_paths.append(href)
                elif href.lower().endswith(".ppt") or href.lower().endswith(".pptx"):
                    ppt_paths.append(href)

        # Also match raw links in the HTML source
        for match in url_pattern.finditer(html):
            url = match.group(0)
            if url.lower().endswith(".pdf"):
                pdf_paths.append(url)
            elif url.lower().endswith(".ppt") or url.lower().endswith(".pptx"):
                ppt_paths.append(url)

    doc_text_blocks = []

    for section in json_data.get("SectionList", []):
        section_title = section.get("Title", "").lower()
        if section_title in ["completion time", "duration", "time"]:
            continue

        for content in section.get("ContentList", []):
            extract_from_html_and_append(content.get("Primary", ""), doc_text_blocks)
            extract_from_html_and_append(content.get("Secondary", ""), doc_text_blocks)

            for sub in content.get("SubContentList", []):
                extract_from_html_and_append(sub.get("Content", ""), doc_text_blocks)
                extract_from_html_and_append(sub.get("Primary", ""), doc_text_blocks)
                extract_from_html_and_append(sub.get("Secondary", ""), doc_text_blocks)

    # Combine everything into a single paragraph
    if doc_text_blocks:
        full_paragraph = re.sub(r"\s+", " ", " ".join(doc_text_blocks)).strip()
        all_paragraphs = [full_paragraph]
                
        embedding = get_text_embedding(full_paragraph) # ✅ Generate embeddings for non-empty paragraph
        if embedding:
            all_embeddings = [embedding]

    else:
        all_paragraphs = []
        all_embeddings = []

    return all_paragraphs, all_embeddings, image_sources, pdf_paths, ppt_paths





def process_file(file_path, blob_path, metadata, aggregated_data):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            json_data = json.load(f)

        # Extract split paragraphs, embeddings, and file references
        paragraphs, embeddings, image_sources, pdf_sources, pptx_sources = get_data_metadata_embedding(json_data)
        print(len(paragraphs))
        
        # Loop over each paragraph and its embedding to create individual entries
        for para, embed in zip(paragraphs, embeddings):
            output = {
                **metadata,          # Excel metadata
                "text_content": para,        # Chunked paragraph text
                "text_embedding": embed,  # Corresponding embedding vector
                "images": image_sources,
                "pdfs": pdf_sources,
                "ppts": pptx_sources
            }
            aggregated_data.append(output)
        
        print(f"📄 Processed and added {len(paragraphs)} chunks for: {file_path}")
    except Exception as e:
        print(f"❌ Failed to process file {file_path}: {e}")



if __name__ == "__main__":
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    container_client = get_container_client()
    all_data = []

    for item in BLOB_PATHS_TO_DOWNLOAD:
        blob_path = item["BlobPath"]
        local_file, full_blob_path = download_blob(container_client, blob_path, DOWNLOAD_DIR)
        if local_file:
            process_file(local_file, full_blob_path, item, all_data)

    with open(FINAL_OUTPUT_JSON, "w", encoding="utf-8") as f:
        json.dump(all_data, f, indent=2, ensure_ascii=False)
    print(f"✅ Final JSON saved to: {FINAL_OUTPUT_JSON}")
