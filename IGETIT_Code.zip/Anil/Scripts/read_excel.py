import pandas as pd

import pandas as pd
import re

def clean_id(value):
    """
    Cleans CourseID or DocID by:
    - Converting float-like values like 17139.0 to "17139"
    - Replacing any unsafe characters with underscores
    """
    if pd.isna(value):
        return ""
    try:
        return str(int(float(value)))  # Handles float or float-like strings
    except (ValueError, TypeError):
        return re.sub(r"[^\w\-=]", "_", str(value))  # Safe fallback

'''

def get_blob_paths(file_path, sheet_name=0, base_path="course-docs"):
    """
    Reads an Excel file and returns a list of dictionaries containing
    blob path and associated metadata for each document.

    Parameters:
        file_path (str): Path to the Excel file.
        sheet_name (str or int, optional): Name or index of the sheet to read. Default is 0 (first sheet).
        base_path (str): Base path to prepend to FileName for constructing blob paths.

    Returns:
        List[Dict]: List of dictionaries with blob and metadata fields.
    """
    try:
        df = pd.read_excel(file_path, sheet_name=sheet_name)
        print(f"✅ Successfully read: {file_path} (Sheet: {sheet_name})")
        
        required_columns = [
            "FileName", "CategoryName", "SubCategoryName", "CourseID",
            "CourseTitle", "UnitTitle", "DocID", "DocTitle",
            "SkillLevel", "DocURL", "SubscriptionIDs"
        ]
        missing = [col for col in required_columns if col not in df.columns]
        if missing:
            raise ValueError(f"❌ Missing required columns in Excel: {missing}")
        
        results = []
        for _, row in df.iterrows():
            filename = row["FileName"]
            if pd.isna(filename):
                continue
            
            item = {
                "BlobPath": f"{base_path}/{filename.strip()}",
                "CategoryName": row["CategoryName"],
                "SubCategoryName": row["SubCategoryName"],
                "CourseID": row["CourseID"],
                "CourseTitle": row["CourseTitle"],
                "UnitTitle": row["UnitTitle"],
                "DocID": row["DocID"],
                "DocTitle": row["DocTitle"],
                "SkillLevel": row["SkillLevel"],
                "DocURL": row["DocURL"],
                "SubscriptionIDs": row["SubscriptionIDs"]
            }
            results.append(item)
        
        return results

    except Exception as e:
        print(f"❌ Failed to read Excel file: {e}")
        return None
 '''   

def get_blob_paths(file_path, sheet_name=0, base_path="course-docs"):
    """
    Reads an Excel file and returns filtered blob paths and metadata based on CategoryName.
    - If 'NX' is present, only keep rows with SubCategoryName == 'NX 2412 Series'.
    - If 'CATIA V5' is present, only keep rows with SubCategoryName == 'CATIA V5 R33'.
    """
    try:
        df = pd.read_excel(file_path, sheet_name=sheet_name)
        df["CourseID"] = df["CourseID"].astype(str)  # Ensure CourseID is string
        print(f"✅ Successfully read: {file_path} (Sheet: {sheet_name})")

        required_columns = [
            "FileName", "CategoryName", "SubCategoryName", "CourseID",
            "CourseTitle", "UnitTitle", "DocID", "DocTitle",
            "SkillLevel", "DocURL", "SubscriptionIDs"
        ]
        missing = [col for col in required_columns if col not in df.columns]
        if missing:
            raise ValueError(f"❌ Missing required columns in Excel: {missing}")

        # Filter based on known subcategory
        if "NX" in df["CategoryName"].unique():
            df = df[df["SubCategoryName"] == "NX 2412 Series"]
        elif "CATIA V5" in df["CategoryName"].unique():
            df = df[df["SubCategoryName"] == "CATIA V5 R33"]

        #df = df.head(10)  # Remove this in production

        results = []
        for _, row in df.iterrows():
            filename = row["FileName"]
            if pd.isna(filename):
                continue

            course_id = clean_id(row["CourseID"])
            doc_id = clean_id(row["DocID"])

            item = {
                "id": f"{course_id}_{doc_id}",  # Safe composite key
                "BlobPath": f"{base_path}/{filename.strip()}",
                "CategoryName": row["CategoryName"],
                "SubCategoryName": row["SubCategoryName"],
                "CourseID": course_id,
                "CourseTitle": row["CourseTitle"],
                "UnitTitle": row["UnitTitle"],
                "DocID": doc_id,
                "DocTitle": row["DocTitle"],
                "SkillLevel": row["SkillLevel"],
                "DocURL": row["DocURL"],
                "SubscriptionIDs": [
                    s.strip() for s in str(row["SubscriptionIDs"]).split(",") if s.strip()
                ]
            }

            results.append(item)

        return results

    except Exception as e:
        print(f"❌ Failed to read Excel file: {e}")
        return None





if __name__=="__main__":
    blob_paths= get_blob_paths(r'Scripts\Data\CATIA_Courses.xlsx')
    print(blob_paths[0:3])
    print(len(blob_paths))
    #nx_blob_paths= get_nx_or_catia_blob_paths(r'.\Scripts\Data\NX_Courses.xlsx')
    #print(nx_blob_paths[0:5])