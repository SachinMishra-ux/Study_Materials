import os
from dotenv import load_dotenv
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient

# === Load credentials from .env ===
load_dotenv(override=True)

ENDPOINT  = os.getenv("AZURE_SEARCH_ENDPOINT")        # e.g., "https://your-search-service.search.windows.net"
ADMIN_KEY = os.getenv("AZURE_SEARCH_KEY")      # admin key
INDEX_NAME = os.getenv("INDEX_NAME")    # your index name

def delete_document_from_index(document_id: str):
    """
    Deletes a document with the specified ID from the Azure Cognitive Search index.
    """
    try:
        search_client = SearchClient(
            endpoint=ENDPOINT,
            index_name=INDEX_NAME,
            credential=AzureKeyCredential(ADMIN_KEY)
        )

        # Delete document by primary key (assumes 'id' is the key field)
        result = search_client.delete_documents(documents=[{"id": document_id}])
        print(f"✅ Deleted document with id: {document_id}")
        return result

    except Exception as e:
        print(f"❌ Failed to delete document: {e}")

if __name__ == "__main__":
    delete_document_from_index("7ac62c95-b64e-4cc0-a5f9-4ccdb73edd5b")