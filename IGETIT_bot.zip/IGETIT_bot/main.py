import os
import uuid
from typing import List, Optional
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from langchain.schema import Document
from fastapi import FastAPI, HTTPException, status, Depends
from pydantic import BaseModel, Field
from typing import List, Optional
import uvicorn
from src.indexing_without_langchain import (
    build_search_documents,
    generate_embeddings_for_docs,
    upload_documents_to_azure,
)
from src.search_index import initialize_search_client

# from data_loader import load_documents_from_blob, split_documents
from src.new_data_loader import load_documents_from_blob, split_documents
from src.data_preprocessing import clean_html_documents, clean_json_txt_documents
from src.index_helper import create_vector_search_index, validate_documents
from src.new_llm_module import initialize_llm, build_rag_chain
from src.entry import answer_query
from src.new_agent import build_agentic_rag_graph, run_rag_pipeline
from src.constants import INDEX_NAME, CONTAINERS, ACCOUNT
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

endpoint = os.getenv("AZURE_SEARCH_ENDPOINT")
api_key = os.getenv("AZURE_SEARCH_KEY")

from azure.core.pipeline.transport import RequestsTransport

transport = RequestsTransport(connection_verify=False)

llm = initialize_llm()
rag_chain = build_rag_chain(llm)
# === Build the graph once at startup ===
compiled_graph = build_agentic_rag_graph()


# --- Data Models ---
class SearchRequest(BaseModel):
    search_text: str = Field("Convergent Body", description="Text to search for")
    select_fields: List[str] = Field(
        default=["id", "content", "source"],
        description="Fields to include in the results",
    )
    top_n: int = Field(4, description="Maximum number of results to return")


# Request body model for uploading documents
class UploadResponse(BaseModel):
    message: str
    uploaded_count: int = 0
    failed_count: int = 0
    errors: List[str] = []


class IndexResponse(BaseModel):  # added for create index api
    message: str
    index_name: str


# --- Data Models ---
class DocumentInput(BaseModel):
    page_content: str = Field(..., description="Text content of the document")
    metadata: dict = Field({}, description="Metadata associated with the document")
    embedding: List[float] = Field(
        ..., description="Embedding vector for the document"
    )  # Added embedding


class SampleDocumentInput(BaseModel):  # Added this model
    content: str = Field(..., description="Content of the sample document")
    source: str = Field(..., description="Source of the sample document")


class UploadRequest(BaseModel):
    documents: List[DocumentInput] = Field(
        ..., description="List of documents to upload"
    )


class ChatRequest(BaseModel):
    session_id: str = Field(
        ..., description="Unique identifier for the user's chat session"
    )
    message: str = Field(..., description="User message or question")


class ChatResponse(BaseModel):
    response: str = Field(..., description="LLM-generated response")


def perform_search_json(
    search_client: SearchClient,
    search_text: str,
    select_fields: List[str],
    top_n: int = 4,
):
    """
    Performs a search against the Azure Search index.

    Args:
        search_client:  Initialized Azure Search Client.
        search_text: The text to search for.
        select_fields: The fields to return in the search results.
        top_n: The maximum number of results to return.

    Returns:
        A list of dictionaries, where each dictionary represents a search result.
        Returns an empty list if no results are found or an error occurs.
    """
    try:
        results = search_client.search(search_text, select=select_fields, top=top_n)
        # Convert the SearchResult objects to dictionaries for easier handling in FastAPI
        return [
            {k: v for k, v in result.items()}  # Convert to a standard dictionary
            for result in results
        ]
    except Exception as e:
        print(f"Search failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Search operation failed: {e}",
        )


# --- FastAPI Setup ---
app = FastAPI()
# --- API Endpoints ---


@app.get("/", status_code=status.HTTP_200_OK)
async def home():
    """
    Returns a welcome message.  Useful for checking if the API is running.
    """
    return {"message": "Welcome to the Document Upload API"}


@app.post("/create_index", response_model=IndexResponse)  # Added create index
async def create_index(index_name: str):
    """
    Creates a vector search index in Azure Search.

    Args:
        index_name (str): The name of the index to create.
    """
    try:
        create_vector_search_index(index_name, endpoint, api_key)
        return IndexResponse(
            message=f"Successfully created index: {index_name}", index_name=index_name
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create index: {e}")


@app.post("/upload_documents", response_model=UploadResponse)
async def upload_documents(index_name: str):  # Changed here
    """
    Loads documents from Azure Blob Storage, processes them, generates embeddings,
    and uploads them to Azure Search.  This single API endpoint handles all the steps.
    """
    uploaded_count = 0
    failed_count = 0
    errors = []

    try:
        # 1. Load documents from Azure Blob Storage
        docs = load_documents_from_blob(CONTAINERS, ACCOUNT)

        if not docs:
            raise HTTPException(
                status_code=400,
                detail="No documents found in the specified Blob Storage containers.",
            )

        # 2. Preprocess documents
        docs = clean_html_documents(docs)
        docs = clean_json_txt_documents(docs)

        # 3. Split documents
        split_docs = split_documents(docs)

        # 4. Generate embeddings
        embedded_docs = generate_embeddings_for_docs(split_docs)

        # 5. Build Azure Search documents
        azure_docs = build_search_documents(embedded_docs)

        # 6. Upload documents to Azure Search
        try:
            upload_documents_to_azure(
                index_name, azure_docs, endpoint, api_key
            )  # Changed Here
            uploaded_count = len(azure_docs)
            message = "Documents uploaded from Blob Storage."
        except Exception as upload_error:
            failed_count = len(azure_docs)
            errors.append(f"Failed to upload documents: {upload_error}")
            message = "Error uploading documents."

    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error processing and uploading documents: {e}"
        )

    return UploadResponse(
        message=message,
        uploaded_count=uploaded_count,
        failed_count=failed_count,
        errors=errors,
    )


# --- API Endpoints ---
@app.post("/search_documents", status_code=status.HTTP_200_OK)
async def search_azure(request: SearchRequest):
    """
    Performs a search against the Azure Search index.
    """

    if not endpoint or not api_key:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Azure Search endpoint or API key not configured.",
        )
    try:
        # Initialize search client
        search_client = initialize_search_client(
            endpoint, api_key, INDEX_NAME, transport
        )
        # Perform search
        results = perform_search_json(
            search_client, request.search_text, request.select_fields, request.top_n
        )
        return {"results": results}  # Wrap the results in a dictionary

    except HTTPException as e:
        raise e  # Re-raise the HTTPException
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An unexpected error occurred: {e}",
        )


@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """
    Handles user messages and returns LLM-generated responses based on RAG pipeline.
    """
    try:
        response = answer_query(request.message, request.session_id, rag_chain)
        return ChatResponse(response=response)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing chat: {e}")


# === Define the chat agent endpoint ===
@app.post("/chat_agent")
async def chat_agent(req: ChatRequest):
    try:
        final_answer = run_rag_pipeline(
            question=req.message,
            session_id=req.session_id,
            compiled_graph=compiled_graph,
        )
        return {"answer": final_answer}
    except Exception as e:
        return {"error": str(e)}


@app.post("/upload_sample_document")
async def upload_sample_document(
    sample_document_input: SampleDocumentInput,
):  # Changed):
    """
    Uploads a single, pre-defined document to Azure Search.  This is for demonstration
    or testing purposes, to upload a document with a specific embedding.

    Args:
        index_name (str): The name of the Azure Search index.
        sample_document_input (SampleDocumentInput): content of the sample document
    """
    try:
        #  Format the document for Azure Search.
        azure_doc = {
            "id": str(uuid.uuid4()),
            "content": sample_document_input.content,  # Use content from input
            "source": sample_document_input.source,  # Default source
            "content_vector": [0.2] * 1536,  # default embedding vector
        }
        validate_documents([azure_doc])  # Validate before upload

        # Initialize search client
        search_client = initialize_search_client(
            endpoint, api_key, INDEX_NAME, transport
        )

        upload_result = search_client.upload_documents(documents=[azure_doc])

        if upload_result[0].succeeded:
            return {"message": "Sample document uploaded successfully."}
        else:
            raise HTTPException(
                status_code=500,
                detail=f"Failed to upload document: {upload_result[0].error_message}",
            )

    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error uploading sample document: {e}"
        )


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000) 
