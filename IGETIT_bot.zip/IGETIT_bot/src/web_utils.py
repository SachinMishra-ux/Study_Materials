# web_utils.py

import os
from typing import List, Tuple
from langchain.schema import Document
from langchain_community.utilities.serpapi import SerpAPIWrapper
from langchain_core.language_models import BaseLanguageModel
from new_llm_module import initialize_llm

import requests
from functools import wraps

# Patch requests.get to always pass verify=False
original_get = requests.get


# @wraps(original_get)
# def unsafe_get(*args, **kwargs):
#     kwargs["verify"] = False
#     return original_get(*args, **kwargs)


# requests.get = unsafe_get

# Initialize SerpAPI
search = SerpAPIWrapper(serpapi_api_key=os.getenv("SERP_API_KEY"))


def run_web_search(query: str) -> List[Tuple[str, str]]:
    """
    Perform a web search and return a list of (snippet, URL) pairs.
    """
    print(f"🌐 Searching web for: {query}")
    results = search.results(query)

    if isinstance(results, dict) and "organic_results" in results:
        top_results = []
        for res in results["organic_results"]:
            snippet = res.get("snippet", "")
            link = res.get("link", "")
            if snippet and link:
                top_results.append((snippet, link))
        return top_results[:3]
    else:
        return [("No search results found.", "N/A")]


def summarize_and_format_results(
    results: List[Tuple[str, str]], query: str, llm: BaseLanguageModel
) -> Document:
    """
    Use LLM to summarize web results and attach top sources.
    """
    # Format the context for summarization
    context = ""
    for i, (snippet, link) in enumerate(results, 1):
        context += f"[{i}] {snippet}\nURL: {link}\n\n"

    prompt = f"""
You are a helpful assistant. Summarize the following web results to answer the question.
Include key findings and mention the numbered sources if relevant.

Question: {query}

Web Results:
{context}

Answer (include references like [1], [2] etc if used):
"""

    # print("\n[Debug] Prompt sent to LLM:\n", prompt)
    summary = llm.invoke(prompt)

    if hasattr(summary, "content"):
        summary_text = summary.content
    else:
        summary_text = str(summary)

    # Format references section with clickable links
    references = "\n\nSources:\n" + "\n".join(
        [f"[{i+1}] {link}" for i, (_, link) in enumerate(results)]
    )

    return Document(
        page_content=summary_text.strip() + references,
        metadata={"source": "web_search", "query": query},
    )


def fetch_web_documents(query: str, llm: BaseLanguageModel) -> List[Document]:
    """
    Run a web search and return summarized documents with source links.
    """
    results = run_web_search(query)
    doc = summarize_and_format_results(results, query, llm)
    return [doc]


if __name__=="__main__":
    fetch_web_documents("Hello World",llm=initialize_llm())
    
