# data_loader.py
import os
from typing import List
from azure.storage.blob import ContainerClient
from data_preprocessing import (
    clean_html_documents,
    clean_json_txt_documents,
    load_and_clean_html_from_blob,
    parse_srt_with_timestamps,
    load_pptx_as_documents,
)
from constants import CONTAINERS, ACCOUNT

from langchain_community.document_loaders import (
    UnstructuredPDFLoader,
    TextLoader,
    UnstructuredWordDocumentLoader,
)
from langchain.schema import Document

import tempfile
from azure.storage.blob import BlobServiceClient




from azure.core.pipeline.transport import RequestsTransport

# Disable SSL certificate verification for Azure Blob storage requests
transport = RequestsTransport(connection_verify=False)

from langchain.text_splitter import RecursiveCharacterTextSplitter


def list_blobs_sorted_by_name(container_client):
    return sorted(list(container_client.list_blobs()), key=lambda b: b.name)


def get_loader_from_blob(
    container_name: str, blob_name: str, account_name: str, video_map: dict = None
) -> List[Document]:
    print(
        f"\n📥 Attempting to load blob: '{blob_name}' from container: '{container_name}'"
    )
    ext = os.path.splitext(blob_name)[-1].lower()
    connection_string = os.getenv("AZURE_STORAGE_CONNECTION_STRING")

    try:
        container_client = ContainerClient.from_connection_string(
            conn_str=connection_string,
            container_name=container_name,
            transport=transport,
        )
        blob_client = container_client.get_blob_client(blob_name)
        blob_data = blob_client.download_blob().readall()
        print(f"✅ Downloaded blob '{blob_name}' (Size: {len(blob_data)} bytes)")
    except Exception as e:
        print(f"❌ Failed to download blob '{blob_name}': {e}")
        return []

    blob_url = (
        f"https://{account_name}.blob.core.windows.net/{container_name}/{blob_name}"
    )

    try:
        if ext == ".pdf":
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
                tmp.write(blob_data)
                tmp.flush()
                loader = UnstructuredPDFLoader(tmp.name)
                docs = loader.load()

        elif ext == ".txt":
            with tempfile.NamedTemporaryFile(delete=False, suffix=".txt") as tmp:
                tmp.write(blob_data)
                tmp.flush()
                loader = TextLoader(tmp.name, autodetect_encoding=True)
                docs = loader.load()

        elif ext == ".html":
            return load_and_clean_html_from_blob(blob_data, blob_url)

        elif ext == ".docx":
            with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as tmp:
                tmp.write(blob_data)
                tmp.flush()
                loader = UnstructuredWordDocumentLoader(tmp.name)
                docs = loader.load()

        elif ext == ".pptx":
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pptx") as tmp:
                tmp.write(blob_data)
                tmp.flush()
                docs = load_pptx_as_documents(tmp.name, blob_url)

        elif ext == ".srt":
            with tempfile.NamedTemporaryFile(delete=False, suffix=".srt") as tmp:
                tmp.write(blob_data)
                tmp.flush()
                mapped_video_url = (
                    video_map.get(blob_name)
                    if video_map and blob_name in video_map
                    else blob_url
                )
                docs = parse_srt_with_timestamps(tmp.name, mapped_video_url)

        else:
            print(f"⚠️ Unsupported file type: '{ext}'")
            return []

        for doc in docs:
            doc.metadata["source"] = mapped_video_url if ext == ".srt" else blob_url
        print(f"📄 Loaded {len(docs)} document(s) from {blob_name}.")
        return docs

    except Exception as e:
        print(f"❌ Error parsing file {blob_name}: {e}")
        return []


def load_documents_from_blob(
    containers: List[str], account_name: str
) -> List[Document]:
    all_docs = []
    connection_string = os.getenv("AZURE_STORAGE_CONNECTION_STRING")

    for container in containers:
        try:
            container_client = ContainerClient.from_connection_string(
                conn_str=connection_string,
                container_name=container,
                transport=transport,
            )
            blobs = list_blobs_sorted_by_name(container_client)

            video_blobs = [b for b in blobs if b.name.endswith(".mp4")]
            transcript_blobs = [b for b in blobs if b.name.endswith(".srt")]
            other_blobs = [
                b
                for b in blobs
                if b.name.lower().endswith((".pdf", ".txt", ".html", ".docx", ".pptx"))
            ]

            print(
                f"✅ Found {len(video_blobs)} videos and {len(transcript_blobs)} transcripts"
            )

            video_map = {}
            for i, transcript in enumerate(transcript_blobs):
                if i < len(video_blobs):
                    video_map[transcript.name] = (
                        f"https://{ACCOUNT}.blob.core.windows.net/{container}/{video_blobs[i].name}"
                    )

            for blob in other_blobs:
                try:
                    docs = get_loader_from_blob(container, blob.name, account_name)
                    all_docs.extend(docs)
                except Exception as e:
                    print(
                        f"⚠️ Failed to load {blob.name} from container {container}: {e}"
                    )

            for transcript_blob in transcript_blobs:
                try:
                    docs = get_loader_from_blob(
                        container, transcript_blob.name, account_name, video_map
                    )
                    all_docs.extend(docs)
                except Exception as e:
                    print(f"⚠️ Failed to load transcript {transcript_blob.name}: {e}")

        except Exception as e:
            print(f"❌ Error accessing container {container}: {e}")
    return all_docs


def split_documents(
    documents: List[Document], chunk_size=1000, chunk_overlap=200
) -> List[Document]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, chunk_overlap=chunk_overlap
    )
    return splitter.split_documents(documents)


if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv()
    AZURE_STORAGE_CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

    docs = load_documents_from_blob(CONTAINERS, ACCOUNT)
    docs = clean_html_documents(docs)
    docs = clean_json_txt_documents(docs)
    split_docs = split_documents(docs)

    seen = {
        "pdf": False,
        "txt": False,
        "html": False,
        "docx": False,
        "pptx": False,
        "srt": False,
    }
    for doc in split_docs:
        src = doc.metadata.get("source", "")
        if not seen["pdf"] and src.endswith(".pdf"):
            print("\n📄 PDF Sample:\n", doc.page_content[:500])
            seen["pdf"] = True
        elif not seen["txt"] and src.endswith(".txt"):
            print("\n📝 TXT Sample:\n", doc.page_content[:500])
            seen["txt"] = True
        elif not seen["html"] and src.endswith(".html"):
            print("\n🌐 HTML Sample:\n", doc.page_content[:500])
            seen["html"] = True
        elif not seen["docx"] and src.endswith(".docx"):
            print("\n📃 DOCX Sample:\n", doc.page_content)
            seen["docx"] = True
        elif not seen["pptx"] and src.endswith(".pptx"):
            print("\n📊 PPTX Sample:\n", doc.page_content)
            seen["pptx"] = True
        elif not seen["srt"] and src.endswith(".mp4"):
            print("\n🎬 SRT Sample (mapped to .mp4):\n", doc)
            seen["srt"] = True
        if all(seen.values()):
            break

    print(f"✅ Loaded and split {len(split_docs)} document chunks.")
    print(split_docs[0])
