import logging
from src.llm_module import initialize_llm, prompt, build_rag_chain,get_relevant_documents,format_docs
from src.cosmos_helper import (
    get_semantically_similar_answer,
    save_message,
    generate_query_embedding,
    get_conversation_history,
    format_chat_history,  # ← Add this
)
from langchain.schema import HumanMessage, AIMessage

# === Logging Setup ===
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def get_history_str(session_id: str) -> str:
    history = get_conversation_history(session_id)
    return "\n".join([f"{msg.type.capitalize()}: {msg.content}" for msg in history])



def answer_query(user_question: str, session_id: str, rag_chain) -> str:
    logging.info(f"Answering query: {user_question}")
    try:
        # Step 1: Generate embedding once
        embedding = generate_query_embedding(user_question)

        # Step 2: Check for semantically similar answer
        cached_response = get_semantically_similar_answer(user_question, session_id, embedding)
        if cached_response:
            return cached_response

        # Step 3: Save user input with embedding
        save_message(session_id, "user", user_question, embedding=embedding)

        # Step 4: Get conversation history
        history = get_conversation_history(session_id)

        # Step 4.5: Pre-check document relevance
        relevant_docs = get_relevant_documents(user_question)
        if not relevant_docs:
            quick_response = "I couldn't find any relevant information to answer your question."
            save_message(session_id, "assistant", quick_response)
            return quick_response
        
        '''formatted_prompt = prompt.format(
        context=format_docs(relevant_docs),
        chat_history=get_history_str(session_id),
        question=user_question
        )
        print("\n===== Prompt Sent to LLM =====\n")
        print(formatted_prompt)'''

        # Step 5: Run RAG chain
        result = rag_chain.invoke(
            {
                "question": user_question,
                "chat_history": format_chat_history(history),
            },
            config={"callbacks": [], "metadata": {}, "chat_history": history}
        )


        # Step 6: Save assistant reply
        save_message(session_id, "assistant", result.content)

        logging.info(f"Query result: {result.content}")
        return result.content

    except Exception as e:
        logging.error(f"Error while answering query: {e}")
        raise



if __name__ == "__main__":
    session_id = "test_session_002"
    print("Chat session started. Type 'exit' to quit.\n")

    # === Initialize LLM and RAG Chain ===
    llm = initialize_llm()
    rag_chain = build_rag_chain(llm)

    while True:
        user_input = input("You: ")
        if user_input.lower() in {"exit", "quit"}:
            print("Chat session ended.")
            break
        try:
            answer = answer_query(user_input, session_id, rag_chain)
            print(f"Bot: {answer}\n")
        except Exception as e:
            print(f"An error occurred: {e}")
