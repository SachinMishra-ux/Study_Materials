from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SimpleField,
    SearchableField,
    SearchFieldDataType,
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchAlgorithmKind,
    VectorSearchProfile,
    SemanticConfiguration,
    SemanticField,
    SemanticSettings,
)

from azure.core.pipeline.transport import RequestsTransport

transport = RequestsTransport(connection_verify=False)
import os
from dotenv import load_dotenv

load_dotenv()

endpoint = os.getenv("AZURE_SEARCH_ENDPOINT")
api_key = os.getenv("AZURE_SEARCH_KEY")

index_name = "course-index1"

# Dimensions used by text-embedding-ada-002
embedding_dimensions = 1536

# Create client
credential = AzureKeyCredential(api_key)
client = SearchIndexClient(
    endpoint=endpoint, credential=credential, transport=transport
)

# Define vector search config
vector_search = VectorSearch(
    algorithms=[
        HnswAlgorithmConfiguration(
            name="default-hnsw",
            kind=VectorSearchAlgorithmKind.HNSW,
            parameters={"metric": "cosine"},
        )
    ],
    profiles=[
        VectorSearchProfile(
            name="default-vector-profile", algorithm_configuration_name="default-hnsw"
        )
    ],
)


# define semantic_config
semantic_config = SemanticConfiguration(
    name="default-semantic-config",
    prioritized_fields={
        "titleField": SemanticField(field_name="title"),
        "contentFields": [SemanticField(field_name="content")],
        "keywordsFields": [SemanticField(field_name="keywords")],
    },
)

semantic_settings = SemanticSettings(configurations=[semantic_config])


# Define the index
index = SearchIndex(
    name=index_name,
    fields=[
        SimpleField(name="id", type=SearchFieldDataType.String, key=True),
        SearchableField(name="title", type=SearchFieldDataType.String, sortable=True),
        SearchableField(name="content", type=SearchFieldDataType.String),
        SimpleField(
            name="contentVector",
            type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
            searchable=True,
            vector_search_dimensions=1536,
            vector_search_profile="default-vector-profile",
        ),
    ],
    semantic_settings=[semantic_config],
    vector_search=vector_search,
)

# Create or update the index
try:
    result = client.create_or_update_index(index)
    print(f"Index '{result.name}' created/updated successfully.")
except Exception as e:
    print("Error creating index:", e)
