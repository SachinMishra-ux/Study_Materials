import os
from typing import List, Optional

from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.core.pipeline.transport import RequestsTransport

from constants import INDEX_NAME


def initialize_search_client(
    endpoint: str, api_key: str, index_name: str, transport=None
) -> SearchClient:
    """
    Initializes and returns an Azure Search Client.

    Args:
        endpoint (str): The endpoint URL of your Azure AI Search service.
        api_key (str): The API key for your Azure AI Search service.
        index_name (str): The name of the index to search.
        transport: Optional transport layer (e.g., to disable SSL verification)

    Returns:
        SearchClient: An initialized Azure Search Client.
    """
    try:
        print(f"🔌 Initializing search client for index: {index_name}")
        credential = AzureKeyCredential(api_key)
        search_client = SearchClient(
            endpoint=endpoint,
            index_name=index_name,
            credential=credential,
            transport= transport
        )
        print("✅ Search client initialized.")
        return search_client
    except Exception as e:
        print(f"❌ Failed to initialize SearchClient: {e}")
        raise


def perform_search(
    search_client: SearchClient,
    search_text: str,
    select_fields: List[str],
    top_n: int = 3,
    filter_expr: Optional[str] = None,
) -> List[dict]:
    """
    Performs a search on the Azure AI Search index.

    Args:
        search_client (SearchClient): An initialized search client.
        search_text (str): The query string to search.
        select_fields (List[str]): List of fields to include in the results.
        top_n (int): Number of top results to return.
        filter_expr (str, optional): Optional filter expression (OData syntax).

    Returns:
        List[dict]: List of search results as dictionaries.
    """
    try:
        print(f"\n🔍 Performing search for: '{search_text}' (top {top_n})")
        response = search_client.search(
            search_text, select=select_fields, top=top_n, filter=filter_expr
        )
        results = []
        for result in response:
            result_dict = dict(result)
            results.append(result_dict)
            print(
                f"➡️  {result_dict.get('content', '')[:150]}..."
            )  # Print content snippet

        print(f"✅ Search completed with {len(results)} results.\n")
        return results

    except Exception as e:
        print(f"❌ Search failed: {e}")
        return []


if __name__ == "__main__":
    # Retrieve Azure Search service details from environment variables
    endpoint = os.getenv("AZURE_SEARCH_ENDPOINT")
    api_key = os.getenv("AZURE_SEARCH_KEY")

    if not endpoint or not api_key:
        print(
            "Error: Please set the AZURE_SEARCH_ENDPOINT and AZURE_SEARCH_API_KEY environment variables."
        )
    else:
        transport = RequestsTransport(connection_verify=False)
        # Initialize the search client
        search_client = initialize_search_client(
            endpoint, api_key, INDEX_NAME,transport=transport
        )

        # Define the search query and fields to select
        # search_text = "KEY FUNCTIONS OF A 5 IN 1 UNIT"  # Change this to your desired search query
        search_text = "to display the available roles"
        select_fields = [
            "id",
            "content",
            "source",
        ]  # Specify the fields you want in the results

        # Perform the search and print the results
        results = perform_search(search_client, search_text, select_fields)

        for result in results:
            print(f"ID: {result['id']}")
            print(f"content: {result['content']}")
            print(f"source: {result['source']}")
            print("-" * 20)  # Separator for readability
