from typing import TypedDict, List, Optional, Callable
from langchain.schema import Document
from langgraph.graph import StateGraph, END

from web_utils import fetch_web_documents
from cosmos_helper import (
    get_conversation_history,
    format_chat_history,
    get_semantically_similar_answer,
    generate_query_embedding,
    save_message,
)
from llm_module import build_rag_chain, initialize_llm, get_relevant_documents

# Initialize LLM & RAG chain
_llm = initialize_llm()
_rag_chain = build_rag_chain(_llm)


# === Define the State Schema ===
class RAGState(TypedDict):
    question: str
    session_id: str
    embedding: List[float]
    chat_history: str
    documents: List[Document]
    answer: Optional[str]
    next: Optional[str]
    web_searched: Optional[bool]
    from_cache: Optional[bool]
    log_callback: Optional[Callable[[str], None]]  # New: callback for streaming logs


# === Nodes ===


def log(state: RAGState, message: str):
    if callback := state.get("log_callback"):
        callback(message)


def compute_embedding_node(state: RAGState):
    # log(state, "🔍 Computing query embedding...")
    emb = generate_query_embedding(state["question"])
    return {"embedding": emb, "next": "check_cached_answer"}


def check_cache_node(state: RAGState):
    log(state, "🧠 Checking semantic cache...")
    cached_answer = get_semantically_similar_answer(
        question=state["question"],
        session_id=state["session_id"],
        query_embedding=state["embedding"],
        threshold=0.95,
    )
    if cached_answer:
        # log(state, "✅ Found cached answer.")
        return {"answer": cached_answer, "next": "END"}
    log(state, "❌ No cached answer found.")
    return {"next": "summarize_history"}


def summarize_history_node(state: RAGState):
    log(state, "📜 Fetching chat history...")
    history = get_conversation_history(state["session_id"])
    formatted = format_chat_history(history)
    return {"chat_history": formatted, "next": "check_history_answer"}


def check_history_answer_node(state: RAGState):
    log(state, "🤔 Checking if chat history has an answer...")
    result = _rag_chain.invoke(
        {
            "question": state["question"],
            "chat_history": state.get("chat_history", ""),
            "context": [],
        }
    )
    answer_text = getattr(result, "content", str(result)).strip()
    if "internal docs are not sufficient" in answer_text.lower():
        log(state, "⚠️ History not enough. Moving to internal doc search.")
        return {"next": "check_docs"}

    log(state, "✅ Answer found from history.")
    save_message(
        state["session_id"], "user", state["question"], embedding=state["embedding"]
    )
    save_message(state["session_id"], "assistant", answer_text)
    return {"answer": answer_text, "next": "END"}


def check_docs_node(state: RAGState):
    log(state, "📚 Searching internal documents...")
    if state.get("web_searched"):
        return {"next": "generate_answer"}

    docs = get_relevant_documents(state["question"])
    if docs:
        log(state, f"✅ Found {len(docs)} relevant documents.")
        return {"documents": docs, "next": "generate_answer"}

    log(state, "❌ No relevant internal docs. Falling back to web search.")
    return {"next": "web_search"}


def web_search_node(state: RAGState):
    log(state, "🌐 Performing web search...")
    docs = fetch_web_documents(state["question"], _llm)
    if docs:
        log(state, f"✅ Web search found {len(docs)} documents.")
        return {"documents": docs, "web_searched": True, "next": "generate_answer"}
    log(state, "❌ Web search failed to find relevant content.")
    return {
        "answer": "❌ I couldn't find anything relevant on the web either.",
        "web_searched": True,
        "next": "END",
    }


def generate_answer_node(state: RAGState):
    log(state, "📝 Generating answer...")
    docs = state.get("documents", [])
    save_message(
        state["session_id"], "user", state["question"], embedding=state["embedding"]
    )

    if state.get("web_searched") and docs:
        web_answer = docs[0].page_content.strip()
        log(state, "✅ Using web search result as answer.")
        save_message(state["session_id"], "assistant", web_answer)
        return {**state, "answer": web_answer, "next": "END"}

    result = _rag_chain.invoke(
        {
            "question": state["question"],
            "chat_history": state["chat_history"],
            "context": docs,
        }
    )
    answer_text = getattr(result, "content", str(result)).strip()
    if "internal docs are not sufficient" in answer_text.lower() and not state.get(
        "web_searched"
    ):
        log(state, "⚠️ Internal docs not sufficient. Trying web search...")
        return {**state, "next": "web_search"}

    log(state, "✅ Final answer generated.")
    save_message(state["session_id"], "assistant", answer_text)
    return {**state, "answer": answer_text, "next": "END"}


# === Graph builder ===
def build_agentic_rag_graph():
    wf = StateGraph(state_schema=RAGState)
    wf.add_node("compute_embedding", compute_embedding_node)
    wf.add_node("check_cached_answer", check_cache_node)
    wf.add_node("summarize_history", summarize_history_node)
    wf.add_node("check_history_answer", check_history_answer_node)
    wf.add_node("check_docs", check_docs_node)
    wf.add_node("web_search", web_search_node)
    wf.add_node("generate_answer", generate_answer_node)

    wf.set_entry_point("compute_embedding")

    wf.add_conditional_edges(
        "compute_embedding",
        path=lambda s: s["next"],
        path_map={"check_cached_answer": "check_cached_answer"},
    )
    wf.add_conditional_edges(
        "check_cached_answer",
        path=lambda s: s["next"],
        path_map={"summarize_history": "summarize_history", "END": END},
    )
    wf.add_conditional_edges(
        "summarize_history",
        path=lambda s: s["next"],
        path_map={"check_history_answer": "check_history_answer"},
    )
    wf.add_conditional_edges(
        "check_history_answer",
        path=lambda s: s["next"],
        path_map={"check_docs": "check_docs", "END": END},
    )
    wf.add_conditional_edges(
        "check_docs",
        path=lambda s: s["next"],
        path_map={"generate_answer": "generate_answer", "web_search": "web_search"},
    )
    wf.add_edge("web_search", "generate_answer")
    wf.add_conditional_edges(
        "generate_answer",
        path=lambda s: s["next"],
        path_map={"web_search": "web_search", "END": END},
    )

    return wf.compile()


# === Pipeline runner ===
def run_rag_pipeline(
    question: str,
    session_id: str,
    compiled_graph,
    log_callback: Optional[Callable[[str], None]] = None,
) -> str:
    initial_state: RAGState = {
        "question": question,
        "session_id": session_id,
        "embedding": None,
        "chat_history": "",
        "documents": [],
        "answer": None,
        "next": None,
        "web_searched": False,
        "from_cache": False,
        "log_callback": log_callback,
    }
    result = compiled_graph.invoke(initial_state)
    return result.get("answer", "❌ No answer could be generated.")


# === Optional test entrypoint ===
if __name__ == "__main__":
    compiled_graph = build_agentic_rag_graph()
    question = "What is the architecture of the Power Distribution Unit?"
    session_id = "test_session"

    def log(msg):
        print(f"> {msg}")

    answer = run_rag_pipeline(question, session_id, compiled_graph, log_callback=log)
    print("\n✅ Final Answer:", answer)
