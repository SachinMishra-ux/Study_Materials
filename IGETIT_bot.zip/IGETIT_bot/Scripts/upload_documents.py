import json
import os
from azure.identity import DefaultAzureCredential
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from dotenv import load_dotenv


# Define which fields should be kept in the final output
ALLOWED_FIELDS = {
    "id","BlobPath", "CategoryName", "SubCategoryName", "CourseID", "CourseTitle",
    "UnitTitle", "DocID", "DocTitle", "SkillLevel", "DocURL",
    "SubscriptionIDs", "text_content", "text_embedding"
}

def filter_document_fields(document):
    return {key: value for key, value in document.items() if key in ALLOWED_FIELDS}


def save_filtered_document(raw_json_file_path):
    # Step 1: Load the original list of documents from output.json
    with open(raw_json_file_path, "r", encoding="utf-8") as infile:
        documents = json.load(infile)
    
    # Step 2: Filter each document to keep only the relevant fields
    filtered_documents = [filter_document_fields(doc) for doc in documents]
    
    # Step 3: Save the filtered documents to a new JSON file
    output_path = "CATIA_output_filtered.json"
    with open(output_path, "w", encoding="utf-8") as outfile:
        json.dump(filtered_documents, outfile, indent=2)

    print(f"Filtered {len(filtered_documents)} documents and saved to {output_path}")
    
    # Step 4: Return the path to the filtered file
    return output_path





def upload_documents_to_azure_search(json_path, search_endpoint, credential, index_name):
    # Load filtered documents from JSON file
    with open(json_path, "r", encoding="utf-8") as f:
        documents = json.load(f)
    
    # Initialize Azure Search client
    search_client = SearchClient(endpoint=search_endpoint, index_name=index_name, credential=credential)
     
    # Upload documents in batches (max 1000 per call)
    batch_size = 100
    for i in range(0, len(documents), batch_size):
        batch = documents[i:i + batch_size]
        result = search_client.upload_documents(documents=batch)
        print(f"Uploaded batch {i // batch_size + 1}: {len(result)} documents")

    print("✅ All documents uploaded successfully.")


if __name__=="__main__":
    load_dotenv(override=True)
    index_name= os.getenv("INDEX_NAME")
    azure_openai_key= os.getenv("AZURE_OPENAI_API_KEY")
    endpoint = os.getenv("AZURE_SEARCH_ENDPOINT")
    credential = AzureKeyCredential(os.getenv("AZURE_SEARCH_KEY", "")) if len(os.getenv("AZURE_SEARCH_KEY", "")) > 0 else DefaultAzureCredential()
    
    #raw_json_file_path= r"C:\Users\AIChatbot-iGETIT-VM\Desktop\IGETITV2-Learner-ChatBot-API\CATIA_output.json"
    
    #output_path= save_filtered_document(raw_json_file_path)

    upload_documents_to_azure_search(r"C:\Users\smm931389\Desktop\IGETITV2-Learner-ChatBot-API\Video_transcript_data_pipeline\EV_courses_Transcriptions_embedding\ev_clean_data.json",endpoint,credential,index_name)
    