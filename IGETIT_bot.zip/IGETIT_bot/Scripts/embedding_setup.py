from langchain_openai import AzureOpenAIEmbeddings
import os
from typing import Dict, Any, List, Tuple
from dotenv import load_dotenv
load_dotenv(override=True)
os.environ["TIKTOKEN_CACHE_DIR"] = (
    r"C:\Users\smm931389\Desktop\IGETITV2-Learner-ChatBot-API\cl100k_base.tiktoken"
)

def get_azure_openai_embeddings() -> AzureOpenAIEmbeddings:
    """
    Retrieves an AzureOpenAIEmbeddings object configured to use your Azure OpenAI deployment.

    This function reads the necessary configuration from environment variables
    (AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_OPENAI_DEPLOYMENT, AZURE_OPENAI_API_VERSION)
    and returns an instance of AzureOpenAIEmbeddings.

    Returns:
        An AzureOpenAIEmbeddings object, or None if an error occurs.
    """
    try:
        return AzureOpenAIEmbeddings(
            deployment=os.getenv(
                "AZURE_OPENAI_EMBEDDING_DEPLOYMENT"
            ),  # e.g., "text-embedding-ada-002-2"
            model="text-embedding-3-large",
            dimensions= os.getenv("AZURE_OPENAI_EMBEDDING_DIMENSIONS"),
            openai_api_version=os.getenv(
                "AZURE_OPENAI_API_VERSION"
            ),  # e.g., "2023-12-01-preview"
            openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            azure_endpoint=os.getenv(
                "AZURE_OPENAI_ENDPOINT"
            ),  # e.g., "https://<your-resource-name>.openai.azure.com/"
        )
    except Exception as e:
        print(f"Error initializing Azure OpenAI embeddings: {e}")
        raise e
    
def get_text_embedding(text: str) -> List[float]:
    """
    Generate embedding for a given text using Azure OpenAI.
    """
    try:
        embeddings = get_azure_openai_embeddings()
        return embeddings.embed_query(text)
    except Exception as e:
        print(f"Error generating embedding for text: {text[:30]}... -> {e}")
        return []
