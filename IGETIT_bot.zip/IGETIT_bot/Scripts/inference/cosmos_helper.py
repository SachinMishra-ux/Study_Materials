from azure.cosmos import CosmosClient
from azure.cosmos.exceptions import CosmosHttpResponseError

from collections import defaultdict

from langchain.schema import AIMessage, HumanMessage
from datetime import datetime, timezone, timedelta
import os
from typing import List, Dict,Optional
from langchain.schema import Document
import uuid
from langchain.prompts import PromptTemplate
from langchain.chains.llm import LLMChain
from dotenv import load_dotenv

load_dotenv(override=True)
 
# Load credentials
COSMOS_ENDPOINT = os.getenv("COSMOS_ENDPOINT")
COSMOS_KEY = os.getenv("COSMOS_KEY")
COSMOS_DB_NAME = os.getenv("DATABASE_NAME")
COSMOS_CONTAINER_NAME = os.getenv("CONTAINER_NAME")
print("---")
print(COSMOS_ENDPOINT)
print(COSMOS_KEY)
print("---")


# Connect to existing database and container
cosmos_client = CosmosClient(COSMOS_ENDPOINT, COSMOS_KEY)
database = cosmos_client.get_database_client(COSMOS_DB_NAME)
container = database.get_container_client(COSMOS_CONTAINER_NAME)


def save_message(session_id: str, role: str, content: str, user_id: str, sources: Optional[list] = None) -> str:
    message_id = str(uuid.uuid4())  # Generate a clean UUID for the message

    item = {
        "id": message_id,                      # ✅ Manually assign UUID
        "session_id": session_id,
        "role": role,
        "content": content,
        "user_id": user_id,
        "sources": sources or [],
        "timestamp": datetime.utcnow().isoformat()  # Optional: helpful for ordering
    }

    container.upsert_item(item)
    return message_id  # ✅ Return the ID for use in RAG response



def get_conversation_history(session_id: str) -> List:
    query = f"SELECT * FROM c WHERE c.session_id = '{session_id}' ORDER BY c._ts"
    items = list(container.query_items(query, enable_cross_partition_query=True))
    messages = []
    for item in items:
        if item["role"] == "user":
            messages.append(HumanMessage(content=item["content"]))
        elif item["role"] == "assistant":
            messages.append(AIMessage(content=item["content"]))
    return messages



def get_structured_chat_history(session_id: str):
    query = f"""
    SELECT * FROM c 
    WHERE c.session_id = '{session_id}' 
    ORDER BY c._ts
    """
    items = list(container.query_items(query, enable_cross_partition_query=True))

    if not items:
        return None

    # Group messages by user-assistant pairs
    chat_history = []
    current_question = None
    current_time = None

    for item in items:
        role = item.get("role")
        content = item.get("content")
        timestamp = datetime.fromtimestamp(item["_ts"], tz=timezone.utc).isoformat()

        if role == "user":
            current_question = content
            current_time = timestamp
        elif role == "assistant" and current_question:
            sources = item.get("sources", [])
            chat_history.append({
                "question": current_question,
                "answer": content,
                "time": current_time,
                "sources": sources
            })
            current_question = None
            current_time = None

    return {
        "session_id": session_id,
        "chat_history": chat_history
    }




def get_sessions_by_user(user_id: str):
    try:
        now = datetime.now(timezone.utc)
        today_start = datetime(now.year, now.month, now.day, tzinfo=timezone.utc)
        yesterday_start = today_start - timedelta(days=1)
        week_start = today_start - timedelta(days=7)

        query = f"""
        SELECT c.session_id, c.content, c._ts 
        FROM c 
        WHERE c.user_id = '{user_id}' AND c.role = 'user'
        ORDER BY c._ts DESC
        """

        items = list(container.query_items(query, enable_cross_partition_query=True))

        if not items:
            return {
                "message": f"No chat sessions found for user_id: {user_id}",
                "sessions": []
            }

        seen_sessions = set()
        grouped_sessions = defaultdict(list)

        for item in items:
            session_id = item["session_id"]
            if session_id in seen_sessions:
                continue

            seen_sessions.add(session_id)
            content = item.get("content", "")
            ts = datetime.fromtimestamp(item["_ts"], tz=timezone.utc)

            # Determine time slot
            if ts >= today_start:
                slot = 0
            elif ts >= yesterday_start:
                slot = 1
            elif ts >= week_start:
                slot = 2
            else:
                slot = 3

            grouped_sessions[slot].append({
                "Title": content[:100],
                "SessionID": session_id
            })

        slot_labels = {
            0: "Today",
            1: "Yesterday",
            2: "Last Week",
            3: "Older"
        }

        structured_output = []
        for slot in sorted(grouped_sessions.keys()):
            structured_output.append({
                "timeslot": slot,
                "label": slot_labels.get(slot, f"Slot {slot}"),
                "sessions": grouped_sessions[slot]
            })

        return {
            "message": "Sessions retrieved successfully",
            "sessions": structured_output
        }

    except CosmosHttpResponseError as ce:
        return {
            "error": "Database query failed",
            "details": str(ce)
        }
    except Exception as e:
        return {
            "error": "Unexpected error occurred while fetching sessions",
            "details": str(e)
        }



def get_history_str(session_id: str) -> str:
    history = get_conversation_history(session_id)
    return "\n".join([f"{msg.type.capitalize()}: {msg.content}" for msg in history])


def format_chat_history(history: List) -> str:
    """
    Converts a list of LangChain HumanMessage and AIMessage objects into a readable string.
    """
    formatted = []
    for msg in history:
        if isinstance(msg, HumanMessage):
            formatted.append(f"User: {msg.content}")
        elif isinstance(msg, AIMessage):
            formatted.append(f"Assistant: {msg.content}")
    return "\n".join(formatted)




def store_new_document_from_web(
    session_id: str, documents: List[Document], original_question: str
):
    """
    Store the user's original question and the web search-based response in Cosmos DB.
    This ensures both are available for future semantic matching.
    """

    # 1. Store the user question with embedding
    user_item = {
        "id": f"{session_id}_user_web_{os.urandom(4).hex()}",
        "session_id": session_id,
        "role": "user",
        "content": original_question
    }
    container.upsert_item(user_item)

    # 2. Store the assistant's web-generated answer(s)
    for document in documents:
        assistant_item = {
            "id": f"{session_id}_web_{os.urandom(4).hex()}",
            "session_id": session_id,
            "role": "assistant",
            "content": document.page_content,
            "metadata": document.metadata,
        }
        container.upsert_item(assistant_item)


def delete_old_messages(days: int = 7):
    """
    Delete documents older than `days` from the Cosmos DB container.
    Default is 7 days.
    """
    try:
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        cutoff_unix = int(cutoff.timestamp())

        # Query to find documents older than the cutoff
        query = f"""
        SELECT c.id, c.session_id 
        FROM c 
        WHERE c._ts < {cutoff_unix}
        """

        old_items = list(container.query_items(query, enable_cross_partition_query=True))

        if not old_items:
            print("[INFO] No old documents found to delete.")
            return {"deleted": 0, "message": "No old data to delete."}

        deleted_count = 0
        for item in old_items:
            try:
                container.delete_item(item=item['id'], partition_key=item['session_id'])
                deleted_count += 1
            except CosmosHttpResponseError as e:
                print(f"[WARN] Failed to delete item {item['id']}: {str(e)}")

        print(f"[INFO] Deleted {deleted_count} documents older than {days} days.")
        return {"deleted": deleted_count, "message": "Old data deleted."}

    except Exception as e:
        print(f"[ERROR] Failed to delete old messages: {str(e)}")
        return {"deleted": 0, "error": str(e)}


def get_yesterdays_messages():
    """
    Retrieves all documents from Cosmos DB that were created yesterday (UTC).
    """
    try:
        now = datetime.now(timezone.utc)
        today_start = datetime(now.year, now.month, now.day, tzinfo=timezone.utc)
        yesterday_start = today_start - timedelta(days=1)

        # Convert to Unix timestamps
        start_ts = int(yesterday_start.timestamp())
        end_ts = int(today_start.timestamp())

        query = f"""
        SELECT * FROM c 
        WHERE c._ts >= {start_ts} AND c._ts < {end_ts}
        ORDER BY c._ts ASC
        """

        items = list(container.query_items(query, enable_cross_partition_query=True))

        print(f"[INFO] Found {len(items)} messages from yesterday.")
        return items

    except CosmosHttpResponseError as ce:
        print(f"[ERROR] Cosmos query failed: {str(ce)}")
        return []
    except Exception as e:
        print(f"[ERROR] Unexpected error while fetching yesterday's messages: {str(e)}")
        return []



SUMMARY_PROMPT = PromptTemplate.from_template("""
You are an AI assistant. Given the conversation history below, summarize it in a concise paragraph that captures the key context and user goals. Keep it under 100 words.

Chat History:
-------------
{history}

Summary:
""")

def summarize_history_with_llm(llm, history_str: str) -> str:
    chain = LLMChain(llm=llm, prompt=SUMMARY_PROMPT)
    result = chain.invoke({"history": history_str})
    return result["text"].strip()



if __name__ == "__main__":
    #result = delete_old_messages(days=7)
    #print(result)
    messages = get_yesterdays_messages()
    for msg in messages:
        print(msg)

