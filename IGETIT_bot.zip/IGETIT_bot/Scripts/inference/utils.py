from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient

def get_search_client(endpoint: str, index_name: str, api_key: str) -> SearchClient:
    """
    Initializes and returns a SearchClient for the given Azure Cognitive Search index.

    Parameters:
        endpoint (str): Azure Search service endpoint.
        index_name (str): Name of the search index.
        api_key (str): Azure Search admin key.

    Returns:
        SearchClient: Configured search client.
    """
    return SearchClient(
        endpoint=endpoint,
        index_name=index_name,
        credential=AzureKeyCredential(api_key)
    )