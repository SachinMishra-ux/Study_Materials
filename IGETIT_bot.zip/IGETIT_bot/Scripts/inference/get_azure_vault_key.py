from azure.identity import ClientSecretCredential
from azure.keyvault.secrets import SecretClient


import os
from dotenv import load_dotenv


def get_secret_from_key_vault(vault_url: str, tenant_id: str, client_id: str, client_secret: str, secret_name: str) -> str:
    try:
        credential = ClientSecretCredential(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )

        client = SecretClient(vault_url=vault_url, credential=credential)
        secret = client.get_secret(secret_name)
        return secret.value

    except Exception as e:
        raise RuntimeError(f"Failed to fetch secret '{secret_name}': {str(e)}")


if __name__=="__main__":
    load_dotenv(override=True)
    vault_url = os.getenv("VAULT_URL")
    secret_name = os.getenv("SECRET_NAME")


    tenant_id = os.getenv("TENANT_ID")
    client_id = os.getenv("CLIENT_ID")
    client_secret = os.getenv("CLIENT_SECRET")

    jwt_secret = get_secret_from_key_vault(vault_url, tenant_id, client_id, client_secret, secret_name)
    print(f"Fetched JWT_SECRET: {jwt_secret}")

