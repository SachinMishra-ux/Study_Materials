from fastapi import FastAPI, HTTPException, Depends, Response, UploadFile, File
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
from jose import jwt, JWTError
from dotenv import load_dotenv
from pydub import AudioSegment
import requests
import os
import io
from tempfile import NamedTemporaryFile

# === Load .env ===
load_dotenv(override=True)

# === Bearer Scheme ===
bearer_scheme = HTTPBearer()

# === Local imports ===
from Scripts.inference.llm_setup import initialize_llm,get_relevant_documents, build_rag_chain
from Scripts.inference.llm_response import run_rag_pipeline

from Scripts.inference.utils import get_search_client
from Scripts.embedding_setup import get_azure_openai_embeddings

from Scripts.inference.course_category_identification import get_course_intent_from_query

# === Environment Configuration ===
class Settings:
    def __init__(self):
        self.azure_llm_deployment = os.getenv("AZURE_LLM_DEPLOYMENT")
        self.azure_llm_api_version = os.getenv("AZURE_LLM_API_VERSION")
        self.azure_llm_openai_endpoint = os.getenv("AZURE_LLM_OPENAI_ENDPOINT")
        self.azure_llm_api_key = os.getenv("AZURE_OPENAI_API_KEY")

        self.search_endpoint = os.getenv("AZURE_SEARCH_ENDPOINT")
        self.search_key = os.getenv("AZURE_SEARCH_KEY")
        self.index_name = os.getenv("INDEX_NAME")

        self.jwt_secret = os.getenv("JWT_SECRET", "your-secret-key")
        self.jwt_algorithm = os.getenv("JWT_ALGORITHM", "HS256")

        self.azure_tts_api_key = os.getenv("AZURE_TTS_KEY")
        self.azure_tts_endpoint = os.getenv("AZURE_TTS_OPENAI_ENDPOINT")
        self.azure_tts_model_name = os.getenv("AZURE_TTS_MODEL_NAME", "gpt-4o-mini-tts")
        self.azure_tts_api_version = os.getenv("AZURE_TTS_API_VERSION", "2025-03-01-preview")

        # STT-specific config (correct whisper deployment!)
        self.azure_stt_api_key = os.getenv("AZURE_STT_KEY")
        self.azure_stt_endpoint = os.getenv("AZURE_STT_OPENAI_ENDPOINT")
        self.azure_stt_model_name = os.getenv("AZURE_STT_MODEL_NAME", "whisper-1")
        self.azure_stt_api_version = os.getenv("AZURE_STT_MODEL_VERSION", "2023-09-01-preview")

        self._validate()

    def _validate(self):
        missing = []
        for key, value in self.__dict__.items():
            if not value and not key.startswith("_"):
                missing.append(key)
        if missing:
            raise ValueError(f"Missing required environment variables: {', '.join(missing)}")

try:
    config = Settings()
except ValueError as e:
    raise RuntimeError(f"Configuration error: {e}")

# === Initialize Clients ===
embedding_client = get_azure_openai_embeddings()
search_client = get_search_client(config.search_endpoint, config.index_name, config.search_key)
llm = initialize_llm(
    azure_deployment=config.azure_llm_deployment,
    api_version=config.azure_llm_api_version,
    azure_endpoint=config.azure_llm_openai_endpoint,
    api_key=config.azure_llm_api_key,
)

# === FastAPI App ===
app = FastAPI(title="IGETIT Coach API")


# Allow all origins for now (or restrict later for security)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # or specify your frontend URL like ["https://your-frontend.com"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# === Request and Response Models ===
class QueryRequest(BaseModel):
    question: str = Field(..., min_length=5, example="What is generative AI?")

class QueryResponse(BaseModel):
    answer: str
    doc_urls: Optional[list[str]] = Field(default_factory=list)


class TokenRequest(BaseModel):
    session_id: str = Field(..., example="user123-session-456")
    SubscriptionIDs: Optional[list] = Field(default_factory=list)

class TokenResponse(BaseModel):
    token: str

class TTSRequest(BaseModel):
    text: str = Field(..., min_length=1, example="Hello, welcome to your AI Coach!")
    voice: str = Field(default="alloy")

# === Routes ===
@app.get("/chatbot", tags=["Health"])
def read_root():
    return {"message": "App is up"}

@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}

@app.post("/generate_token", response_model=TokenResponse, tags=["Auth"])
def generate_token(request: TokenRequest):
    try:
        payload = {
            "metadata_filter": {
                "session_id": request.session_id,
                "SubscriptionIDs": request.SubscriptionIDs
            },
            "exp": datetime.utcnow() + timedelta(hours=1)
        }
        token = jwt.encode(payload, config.jwt_secret, algorithm=config.jwt_algorithm)
        return {"token": f"Bearer {token}"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating token: {str(e)}")

@app.post("/get_llm_answer", tags=["LLM"])
async def get_llm_answer(
    body: QueryRequest,
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)
):
    token = credentials.credentials
    try:
        payload = jwt.decode(token, config.jwt_secret, algorithms=[config.jwt_algorithm])
        metadata_filter = payload.get("metadata_filter")
        if not metadata_filter:
            raise HTTPException(status_code=400, detail="metadata_filter missing in token")

        session_id = metadata_filter.get("session_id")
        if not session_id:
            raise HTTPException(status_code=400, detail="session_id missing in metadata_filter")

    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired JWT token")

    try:
        # Step 0: Detect course intent and print
        course_intent = get_course_intent_from_query(body.question, llm)
        print(f"\n=== Detected Course Intent: {course_intent} ===\n")

        if course_intent in ["NX", "CATIA", "EV"]:
            metadata_filter["CategoryName"] = course_intent

        # ✅ Run pipeline to get both answer and sources
        result = run_rag_pipeline(
            llm=llm,
            embedding_client=embedding_client,
            search_client=search_client,
            question=body.question,
            session_id=session_id,
            metadata_filter=metadata_filter
        )

        return {
            "answer": result["answer"],
            "sources": result["sources"]
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting LLM answer: {str(e)}")




@app.post("/text_to_speech", tags=["TTS"])
def speak(request: TTSRequest):
    try:
        url = f"{config.azure_tts_endpoint}/openai/deployments/{config.azure_tts_model_name}/audio/speech?api-version={config.azure_tts_api_version}"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {config.azure_tts_api_key}"
        }
        payload = {
            "model": config.azure_tts_model_name,
            "input": request.text,
            "voice": request.voice
        }

        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()

        audio_stream = io.BytesIO(response.content)
        return StreamingResponse(audio_stream, media_type="audio/mpeg")

    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=500, detail=f"TTS request failed: {str(e)}")

# === Correct STT Endpoint (with Whisper) ===
@app.post("/transcribe", tags=["STT"])
async def transcribe_audio(file: UploadFile = File(...)):
    try:
        # Save uploaded file to temp
        ext = file.filename.split(".")[-1]
        temp_input = NamedTemporaryFile(delete=False, suffix=f".{ext}")
        temp_input.write(await file.read())
        temp_input.flush()

        # Convert to mp3
        audio = AudioSegment.from_file(temp_input.name)
        temp_mp3 = temp_input.name.replace(f".{ext}", ".mp3")
        audio.export(temp_mp3, format="mp3")

        # Azure Whisper transcription
        stt_url = f"{config.azure_stt_endpoint}/openai/deployments/{config.azure_stt_model_name}/audio/transcriptions?api-version={config.azure_stt_api_version}"
        print(stt_url)
        headers = {
            "Authorization": f"Bearer {config.azure_stt_api_key}"
        }

        with open(temp_mp3, "rb") as f:
            files = {
                "file": ("audio.mp3", f, "audio/mpeg"),
                "model": (None, config.azure_stt_model_name)
            }
            response = requests.post(stt_url, headers=headers, files=files)

        if response.status_code == 200:
            return {"text": response.json().get("text", "")}
        else:
            raise HTTPException(status_code=response.status_code, detail=response.text)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Transcription failed: {str(e)}")

# === Main for Local Dev ===
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("Scripts.inference.streaming_api:app", host="0.0.0.0", port=8000)
