from setuptools import setup, find_packages

setup(
    name="my_llm_rag_project",
    version="0.1",
    email="sachin.mishra@tatatechnologies.com",
    contact="+91 8928450584",
    packages=find_packages(where="Scripts"),
    package_dir={"": "Scripts"},
    include_package_data=True,
    install_requires=[
        "langchain",
        "openai",
        "python-dotenv",
        "azure-search-documents",
        "langchain-openai"
        # Add others as needed
    ],
    entry_points={
        "console_scripts": [
            "run-inference = inference.llm_inference:main",  # optional: if you define a main()
        ],
    },
)
