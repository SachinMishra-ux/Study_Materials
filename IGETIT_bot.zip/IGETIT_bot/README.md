# 🤖 IGETIT RAG-Based Agentic AI Bot

A production-ready, multi-agent conversational AI assistant designed to intelligently retrieve answers using a **Retrieval-Augmented Generation (RAG)** pipeline. Built specifically for the **IGETIT platform**, this bot combines internal enterprise search with web search fallback for reliable, real-time question answering.

---

## 👤 Repo Owner

**Name:** Sachin Mishra  
**Role:** Data Scientist, Tata Technologies  
**Email:** sachin.mishra@tatatechnologies.com  
**Phone:** +91-8928450584

---

## 📌 Features

- ✅ **Multi-Agent Architecture**  
  - Internal Agent: Fetches answers from embedded enterprise documents using Azure AI Search.  
  - Web Agent: Uses real-time web search when internal data is insufficient.

- 🧠 **RAG Pipeline with LangChain**  
  - Indexes PDFs, DOCX, HTML, and other documents using OpenAI embeddings.
  - Efficient document chunking and vector storage.

- 🎙️ **Speech Capabilities**
  - Input: Converts voice to text using Azure GPT-4o-Transcribe API.
  - Output: Converts assistant replies to speech using TTS and streams to frontend (Streamlit).

- 🌐 **Real-Time Web Search Agent**
  - Searches the internet for up-to-date info using fallback logic.

- 💾 **Caching & Storage**
  - User-bot interactions stored in **Azure Cosmos DB** to reduce repeated LLM calls.

- 🔐 **Authentication**
  - JWT-based auth for secure user access.

- 🧑‍💻 **Streamlit Frontend**
  - Chat UI with markdown + audio support
  - Microphone input for voice queries

---

## 📁 Project Structure

IGETIT-RAG-Agentic-Bot/
├── Scripts/
│ ├── inference/
│ │ ├── streaming_api.py # FastAPI TTS API
│ │ ├── speech_to_text.py # Voice input using GPT-4o-transcribe
│ └── utils/
│ ├── document_loader.py # Azure blob/document parsing
│ ├── embedding_helper.py # Vectorization + Azure AI Search
├── config.toml # Centralized config (email, phone, keys)
├── streamlit_ui.py # Streamlit frontend
├── Dockerfile
└── README.md


---

## 🔧 Technologies Used

| Component         | Tech Stack                              |
|------------------|------------------------------------------|
| Language Model    | OpenAI GPT-4 / GPT-4o (via Azure)        |
| Vector Store      | Azure AI Search                          |
| Orchestration     | LangChain + LangGraph                    |
| Backend API       | FastAPI                                  |
| Frontend UI       | Streamlit                                |
| Voice I/O         | OpenAI TTS + Azure GPT-4o-transcribe     |
| Caching DB        | Azure Cosmos DB                          |
| Deployment        | Docker, Azure VM                         |

---

## 🚀 Setup Instructions

1. **Clone the repo:**

```bash
git clone https://github.com/yourusername/IGETIT-RAG-Agentic-Bot.git
cd IGETIT-RAG-Agentic-Bot
```


- Create Virtual ENV:

```
python -m venv ragbot
.\ragbot\Scripts\activate
```

- If getting issue with SSL, use the below command to install the packages of python
```
pip install beautifulsoup4 --trusted-host pypi.org --trusted-host files.pythonhosted.org

```

`pip install -U :class:`~langchain-openai` and import as `from :class:`~langchain_openai import AzureOpenAIEmbeddings


set PYTHONPATH=%CD%