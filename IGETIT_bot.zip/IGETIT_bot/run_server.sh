# !/bin/bash

# Activate your virtual environment if needed
#source ragbot/bin/activate  # Uncomment if using a virtual environment

# Start the FastAPI server
uvicorn Scripts.inference.streaming_api:app
